# One-click launcher for Dinosaur Hunter 2.0 on Windows 11.
# - Mounts DKDINO.ISO as a virtual disc if it isn't mounted already
# - Points the game's .ini at that drive letter
# - Starts the (patched) game
# Run with -NoLaunch to do everything except start the game.
param([switch]$NoLaunch)
$ErrorActionPreference = 'Stop'

$root = 'D:\DinosaurHunterRebuild'
# Patched copy of the disc: identical except the 20 Indeo videos are re-encoded
# as Cinepak (Windows 11 has no Indeo decoder). Original: 1-original game iso\DKDINO.ISO
$iso  = Join-Path $root '4-playable game\DKDINO-videofix.iso'
$orig = Join-Path $root '1-original game iso\DKDINO.ISO'

# Eject the original disc if it's mounted, so the game finds the patched one.
$o = Get-DiskImage -ImagePath $orig
if ($o.Attached) { Dismount-DiskImage -ImagePath $orig | Out-Null }
$game = Join-Path $root '4-playable game\disc\DKCODE'
$ini  = Join-Path $game 'Dinosaur Hunter.ini'

$img = Get-DiskImage -ImagePath $iso
if (-not $img.Attached) { $img = Mount-DiskImage -ImagePath $iso -PassThru }
$letter = ($img | Get-Volume).DriveLetter
if (-not $letter) { throw 'The ISO is mounted but has no drive letter.' }

# Update only the Data= line so the game's own saved settings are kept.
$lines = Get-Content $ini
$lines = $lines | ForEach-Object { if ($_ -match '^Data=') { "Data=${letter}:\" } else { $_ } }
Set-Content $ini $lines -Encoding ASCII
"Disc mounted as ${letter}:  -> $ini updated"

if (-not $NoLaunch) {
    Start-Process -FilePath (Join-Path $game 'Dinosaur Hunter.exe') -WorkingDirectory $game
}
