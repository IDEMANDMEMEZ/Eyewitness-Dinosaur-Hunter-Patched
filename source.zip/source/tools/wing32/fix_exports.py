"""Rename TCC's decorated stdcall exports (_WinGBitBlt@32) to plain names (WinGBitBlt).

The new name is written over the old one in place and padded with NULs, so the
export table's pointers stay valid. Stripping "_" and "@N" keeps the names in
the same sorted order, which Windows needs for name lookup.

Usage: python fix_exports.py WING32.DLL
"""
import re
import struct
import sys

path = sys.argv[1]
d = bytearray(open(path, 'rb').read())

pe = struct.unpack_from('<I', d, 0x3C)[0]
opt = pe + 24
nsec = struct.unpack_from('<H', d, pe + 6)[0]
optsize = struct.unpack_from('<H', d, pe + 20)[0]
exp_rva = struct.unpack_from('<I', d, opt + 96)[0]       # data directory 0 (32-bit PE)
sections = []
for i in range(nsec):
    s = pe + 24 + optsize + i * 40
    vsize, va, rawsize, rawptr = struct.unpack_from('<IIII', d, s + 8)
    sections.append((va, max(vsize, rawsize), rawptr))


def off(rva):
    for va, size, raw in sections:
        if va <= rva < va + size:
            return rva - va + raw
    raise ValueError(hex(rva))


e = off(exp_rva)
nnames = struct.unpack_from('<I', d, e + 24)[0]
names_rva = struct.unpack_from('<I', d, e + 32)[0]
names = []
for i in range(nnames):
    p = off(struct.unpack_from('<I', d, off(names_rva) + 4 * i)[0])
    end = d.index(b'\0', p)
    old = d[p:end].decode('ascii')
    new = re.sub(r'^_?(.*?)(@\d+)?$', r'\1', old)
    d[p:end] = new.encode('ascii').ljust(end - p, b'\0')
    names.append(new)
    print(f'{old:32} -> {new}')

assert names == sorted(names), 'export names no longer sorted'
open(path, 'wb').write(d)
print('done')
