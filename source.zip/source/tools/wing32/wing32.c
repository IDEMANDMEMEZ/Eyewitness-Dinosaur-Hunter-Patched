/*
 * Stand-in WING32.DLL for running old WinG games on 64-bit Windows.
 *
 * The real WinG 1.0 WING32.DLL thunks to a 16-bit WING.DLL, which 64-bit
 * Windows cannot load. Every WinG call has a direct GDI equivalent
 * (WinG bitmaps are just DIB sections), so this implements them on GDI.
 *
 * Full-page redraw fix: Dinosaur Hunter composes each page in an off-screen
 * WinG bitmap and copies only the changed rectangles to the window. On modern
 * Windows some of those updates (page changes/transitions) never reach the
 * screen, leaving parts of the previous page visible. So whenever the game
 * copies part of a full-page bitmap to a window, we copy the whole page.
 *
 * Settings (dkhelper.ini next to this DLL, section [Graphics]):
 *   FullRedraw=1   whole-page copies (0 = original behaviour)
 *   Log=0          1 = write wing32.log with every WinG drawing call
 *
 * Build as a 32-bit (x86) DLL with TCC, then fix the export names:
 *   tcc -shared -o WING32.DLL wing32.c -lgdi32 -luser32 -lkernel32
 *   python fix_exports.py WING32.DLL
 * or with MinGW:
 *   i686-w64-mingw32-gcc -O2 -shared -o WING32.DLL wing32.c wing32_mingw.def -lgdi32 -luser32
 */
#include <windows.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define EXPORT __declspec(dllexport)

/* Multimedia (WINMM) types used by the start-up trace. TCC has no
   mmsystem.h; the real functions are reached through the game's own
   imports, so nothing here needs linking. */
#ifndef MCI_OPEN
typedef DWORD MCIERROR;
typedef UINT MCIDEVICEID;
typedef UINT MMRESULT;
DECLARE_HANDLE(HWAVEOUT);
typedef HWAVEOUT *LPHWAVEOUT;
typedef struct { WORD wFormatTag, nChannels; DWORD nSamplesPerSec, nAvgBytesPerSec; WORD nBlockAlign, wBitsPerSample, cbSize; } WAVEFORMATEX;
typedef const WAVEFORMATEX *LPCWAVEFORMATEX;
typedef struct wavehdr_tag { LPSTR lpData; DWORD dwBufferLength, dwBytesRecorded; DWORD_PTR dwUser; DWORD dwFlags, dwLoops; struct wavehdr_tag *lpNext; DWORD_PTR reserved; } WAVEHDR, *LPWAVEHDR;
typedef struct { DWORD_PTR dwCallback; MCIDEVICEID wDeviceID; LPCSTR lpstrDeviceType, lpstrElementName, lpstrAlias; } MCI_OPEN_PARMSA;
typedef struct { DWORD_PTR dwCallback, dwReturn; DWORD dwItem, dwTrack; } MCI_STATUS_PARMS;
#define MCI_OPEN 0x0803
#define MCI_STATUS 0x0814
#define MCI_WINDOW 0x0841
#define MCI_PUT 0x0842
#define MCI_WHERE 0x0843
#define MCI_OPEN_ELEMENT 0x00000200L
#define MCI_OPEN_TYPE_ID 0x00001000L
#define MCI_OPEN_TYPE 0x00002000L
#endif

static void path_next_to_dll(char *out, const char *name);
static void start_helper(void);
static void load_settings(void);
static void wlog(const char *fmt, ...);

typedef enum { WING_DISPERSED_4x4, WING_DISPERSED_8x8, WING_CLUSTERED_4x4 } WING_DITHER_TYPE;

static HINSTANCE g_inst;
static int g_full_redraw = 0;
static int g_fix_transitions = 1;
static int g_log = 0;

/* An off-screen memory DC; WinG bitmaps get selected into it. */
static void install_hooks(void);

static void tlog(const char *fmt, ...);

EXPORT HDC WINAPI WinGCreateDC(void)
{
    tlog("WinGCreateDC (game graphics starting)");
    start_helper();
    install_hooks();
    return CreateCompatibleDC(NULL);
}

/* WinG's preferred format: 8-bit, top-down DIB (negative height). */
EXPORT BOOL WINAPI WinGRecommendDIBFormat(BITMAPINFO *bmi)
{
    if (!bmi) return FALSE;
    ZeroMemory(&bmi->bmiHeader, sizeof(BITMAPINFOHEADER));
    bmi->bmiHeader.biSize        = sizeof(BITMAPINFOHEADER);
    bmi->bmiHeader.biWidth       = 1;
    bmi->bmiHeader.biHeight      = -1;
    bmi->bmiHeader.biPlanes      = 1;
    bmi->bmiHeader.biBitCount    = 8;
    bmi->bmiHeader.biCompression = BI_RGB;
    return TRUE;
}

/* A WinG bitmap is a DIB section the app can write to directly. */
EXPORT HBITMAP WINAPI WinGCreateBitmap(HDC hdc, const BITMAPINFO *bmi, void **bits)
{
    void *p = NULL;
    HBITMAP bmp = CreateDIBSection(hdc, bmi, DIB_RGB_COLORS, &p, NULL, 0);
    if (bits) *bits = p;
    return bmp;
}

EXPORT void *WINAPI WinGGetDIBPointer(HBITMAP bmp, BITMAPINFO *bmi)
{
    DIBSECTION ds;
    if (GetObjectA(bmp, sizeof(ds), &ds) != sizeof(ds)) return NULL;
    if (bmi) bmi->bmiHeader = ds.dsBmih;
    return ds.dsBm.bmBits;
}

EXPORT UINT WINAPI WinGGetDIBColorTable(HDC hdc, UINT start, UINT count, RGBQUAD *colors)
{
    return GetDIBColorTable(hdc, start, count, colors);
}

EXPORT UINT WINAPI WinGSetDIBColorTable(HDC hdc, UINT start, UINT count, const RGBQUAD *colors)
{
    if (g_log) wlog("SetDIBColorTable start=%u count=%u", start, count);
    return SetDIBColorTable(hdc, start, count, colors);
}

EXPORT HPALETTE WINAPI WinGCreateHalftonePalette(void)
{
    HDC screen = GetDC(NULL);
    HPALETTE pal = CreateHalftonePalette(screen);
    ReleaseDC(NULL, screen);
    return pal;
}

/* Dithered brushes are unnecessary on true-colour displays. */
EXPORT HBRUSH WINAPI WinGCreateHalftoneBrush(HDC hdc, COLORREF color, WING_DITHER_TYPE type)
{
    (void)hdc; (void)type;
    return CreateSolidBrush(color);
}

/* ---- automatic repaint after page transitions -------------------------- */
static int g_in_paint;               /* set while the game handles WM_PAINT */
static HWND g_repaint_wnd;
static UINT_PTR g_repaint_timer;

/* Bitmaps the game draws finished pages from. Learned from the first
   full-size copy after each repaint we ask for; copies from these never
   trigger another repaint (otherwise the repaint would retrigger itself). */
#define MAX_PAGE_BMPS 32
static HGDIOBJ g_page_bmps[MAX_PAGE_BMPS];
static int g_page_next;
static int g_expect_page;
static DWORD g_expect_since;

static int is_page_bmp(HGDIOBJ b)
{
    int i;
    for (i = 0; i < MAX_PAGE_BMPS; i++) if (g_page_bmps[i] == b) return 1;
    return 0;
}

static void add_page_bmp(HGDIOBJ b)
{
    if (is_page_bmp(b)) return;
    g_page_bmps[g_page_next] = b;
    g_page_next = (g_page_next + 1) % MAX_PAGE_BMPS;
}

static void CALLBACK repaint_now(HWND h, UINT msg, UINT_PTR id, DWORD time)
{
    (void)h; (void)msg; (void)time;
    KillTimer(NULL, id);
    g_repaint_timer = 0;
    if (g_repaint_wnd && IsWindow(g_repaint_wnd)) {
        if (g_log) wlog("auto repaint of whole window");
        g_expect_page = 1;
        g_expect_since = GetTickCount();
        InvalidateRect(g_repaint_wnd, NULL, FALSE);
    }
}

/* (Re)start a short one-shot timer; it fires once the transition's burst of
   copies has finished. Timer callbacks run on the game's own thread. */
static void schedule_repaint(HWND wnd)
{
    g_repaint_wnd = wnd;
    g_repaint_timer = SetTimer(NULL, g_repaint_timer, 80, repaint_now);
}

/* Size of the bitmap currently selected into a memory DC (0 if none). */
static void src_size(HDC src, LONG *w, LONG *h)
{
    BITMAP bm;
    HGDIOBJ obj = GetCurrentObject(src, OBJ_BITMAP);
    *w = *h = 0;
    if (obj && GetObjectA(obj, sizeof(bm), &bm)) { *w = bm.bmWidth; *h = bm.bmHeight; }
}

EXPORT BOOL WINAPI WinGBitBlt(HDC dst, int xd, int yd, int w, int h, HDC src, int xs, int ys)
{
    HWND wnd = WindowFromDC(dst);
    LONG bw, bh;
    src_size(src, &bw, &bh);

    {   /* trace: show that drawing is still happening */
        static LONG n;
        LONG k = InterlockedIncrement(&n);
        if (k <= 5 || k % 200 == 0) tlog("WinGBitBlt #%ld to %s %dx%d", k, wnd ? "window" : "memory", w, h);
    }

    if (g_log) {
        char cls[32] = "-";
        RECT cb = {0, 0, 0, 0};
        int ct = wnd ? GetClipBox(dst, &cb) : 0;
        if (wnd) GetClassNameA(wnd, cls, sizeof(cls));
        wlog("BitBlt to %s %d,%d %dx%d from %d,%d of %ldx%ld clip=%s %ld,%ld-%ld,%ld", wnd ? cls : "memory",
             xd, yd, w, h, xs, ys, bw, bh,
             ct == NULLREGION ? "empty" : ct == SIMPLEREGION ? "rect" : ct == COMPLEXREGION ? "complex" : "-",
             cb.left, cb.top, cb.right, cb.bottom);
    }

    /* Page transitions: on a page change the game blends the old page into
       the new one in a separate transition picture, step by step, timed by
       the clock, copying it to the window after each step. On a modern PC all
       steps run within ~1 ms, so the blend is barely started when the effect
       ends and most of the old page stays on screen. The game's normal
       repaint (what happens after minimise/restore) draws the finished page
       correctly - so shortly after a full-page copy outside a repaint, ask
       the game to repaint its whole window. */
    if (g_fix_transitions && wnd && w >= 600 && h >= 400) {
        HGDIOBJ b = GetCurrentObject(src, OBJ_BITMAP);
        if (g_expect_page && GetTickCount() - g_expect_since > 500) g_expect_page = 0;
        if (g_expect_page) {                 /* first full copy of our repaint */
            g_expect_page = 0;
            add_page_bmp(b);
            if (g_log) wlog("learned page bitmap %p (%ldx%ld)", (void *)b, bw, bh);
        } else if (!g_in_paint && !is_page_bmp(b)) {
            schedule_repaint(wnd);
        }
    }

    /* Whole-page copy: only when drawing to a window, from a page-sized
       bitmap that lines up 1:1 with the window, and it's a partial copy. */
    if (g_full_redraw && wnd && bw >= 600 && bh >= 400 && xd == xs && yd == ys &&
        (w < bw || h < bh)) {
        BOOL ok = BitBlt(dst, 0, 0, bw, bh, src, 0, 0, SRCCOPY);
        if (ok) return TRUE;
    }
    return BitBlt(dst, xd, yd, w, h, src, xs, ys, SRCCOPY);
}

EXPORT BOOL WINAPI WinGStretchBlt(HDC dst, int xd, int yd, int wd, int hd,
                           HDC src, int xs, int ys, int ws, int hs)
{
    int old = SetStretchBltMode(dst, COLORONCOLOR);
    BOOL ok = StretchBlt(dst, xd, yd, wd, hd, src, xs, ys, ws, hs, SRCCOPY);
    SetStretchBltMode(dst, old);
    return ok;
}

/* ---- watching the game's own GDI calls ---------------------------------
 * Patches the game exe's import table so its calls to a few Windows drawing
 * functions go through us first. Used to log (and, if needed, fix) drawing
 * that targets the whole screen instead of the game window: modern Windows
 * composes windows separately and discards drawing done straight onto the
 * screen, which old games used for page transitions.                       */
static int g_screen_redirect = 1;
static HDC (WINAPI *real_GetDC)(HWND);
static int (WINAPI *real_ReleaseDC)(HWND, HDC);
static HDC (WINAPI *real_CreateDCA)(LPCSTR, LPCSTR, LPCSTR, const DEVMODEA *);
static BOOL (WINAPI *real_DeleteDC)(HDC);
static BOOL (WINAPI *real_BitBlt)(HDC, int, int, int, int, HDC, int, int, DWORD);
static int (WINAPI *real_StretchDIBits)(HDC, int, int, int, int, int, int, int, int, const void *, const BITMAPINFO *, UINT, DWORD);
static int (WINAPI *real_SetDIBitsToDevice)(HDC, int, int, DWORD, DWORD, int, int, UINT, UINT, const void *, const BITMAPINFO *, UINT);

static const char *wnd_name(HWND h, char *buf, int n);

#define MAX_REDIRECT 16
static struct { HDC dc; HWND wnd; int created; } g_redirect[MAX_REDIRECT];

static HWND game_window(void)
{
    HWND h = FindWindowA("DKPenge", NULL);
    DWORD pid = 0;
    if (h) GetWindowThreadProcessId(h, &pid);
    return (h && pid == GetCurrentProcessId() && IsWindowVisible(h)) ? h : NULL;
}

/* Give the game a DC for its window, set up so screen coordinates land in
   the right place, in place of a whole-screen DC. */
static HDC redirect_dc(int created)
{
    HWND wnd = game_window();
    HDC dc;
    POINT org = {0, 0};
    int i;
    if (!wnd || !g_screen_redirect) return NULL;
    dc = real_GetDC(wnd);
    if (!dc) return NULL;
    ClientToScreen(wnd, &org);
    SetViewportOrgEx(dc, -org.x, -org.y, NULL);
    for (i = 0; i < MAX_REDIRECT; i++)
        if (!g_redirect[i].dc) { g_redirect[i].dc = dc; g_redirect[i].wnd = wnd; g_redirect[i].created = created; break; }
    return dc;
}

static int take_redirect(HDC dc, HWND *wnd)
{
    int i;
    for (i = 0; i < MAX_REDIRECT; i++)
        if (g_redirect[i].dc == dc) { *wnd = g_redirect[i].wnd; g_redirect[i].dc = NULL; return 1; }
    return 0;
}

static const char *dc_target(HDC dc, char *buf, int n)
{
    HWND w = WindowFromDC(dc);
    int i;
    for (i = 0; i < MAX_REDIRECT; i++) if (g_redirect[i].dc == dc) return "SCREEN->window";
    if (GetObjectType(dc) == OBJ_MEMDC) return "memory";
    if (!w) return "SCREEN";
    if (w == GetDesktopWindow()) return "desktop";
    GetClassNameA(w, buf, n);
    return buf;
}

static HDC WINAPI hook_GetDC(HWND h)
{
    if (!h) {
        HDC r = redirect_dc(0);
        if (r) return r;
    } else if (g_log) {
        char c[32];
        wlog("GetDC %s", wnd_name(h, c, 32));
    }
    return real_GetDC(h);
}

static int WINAPI hook_ReleaseDC(HWND h, HDC dc)
{
    HWND w;
    if (take_redirect(dc, &w)) return real_ReleaseDC(w, dc);
    return real_ReleaseDC(h, dc);
}

static HDC WINAPI hook_CreateDCA(LPCSTR drv, LPCSTR dev, LPCSTR out, const DEVMODEA *dm)
{
    if (drv && _stricmp(drv, "DISPLAY") == 0) {
        HDC r = redirect_dc(1);
        if (g_log) wlog("CreateDC(DISPLAY) - whole screen%s", r ? " -> redirected to game window" : "");
        if (r) return r;
    } else if (g_log) wlog("CreateDC(%s)", drv ? drv : "null");
    return real_CreateDCA(drv, dev, out, dm);
}

static BOOL WINAPI hook_DeleteDC(HDC dc)
{
    HWND w;
    if (take_redirect(dc, &w)) return real_ReleaseDC(w, dc) != 0;
    return real_DeleteDC(dc);
}

static BOOL WINAPI hook_BitBlt(HDC d, int x, int y, int w, int h, HDC s, int xs, int ys, DWORD rop)
{
    if (g_log) {
        char a[32] = "", b[32] = "";
        const char *td = dc_target(d, a, sizeof(a));
        if (strcmp(td, "memory") != 0)
            wlog("gdi BitBlt to %s %d,%d %dx%d from %s %d,%d rop=%06lx", td, x, y, w, h,
                 s ? dc_target(s, b, sizeof(b)) : "none", xs, ys, (unsigned long)rop);
    }
    return real_BitBlt(d, x, y, w, h, s, xs, ys, rop);
}

static int WINAPI hook_StretchDIBits(HDC d, int xd, int yd, int wd, int hd, int xs, int ys, int ws, int hs,
                                     const void *bits, const BITMAPINFO *bi, UINT use, DWORD rop)
{
    if (g_log) { char a[32] = ""; wlog("gdi StretchDIBits to %s %d,%d %dx%d", dc_target(d, a, sizeof(a)), xd, yd, wd, hd); }
    return real_StretchDIBits(d, xd, yd, wd, hd, xs, ys, ws, hs, bits, bi, use, rop);
}

static int WINAPI hook_SetDIBitsToDevice(HDC d, int xd, int yd, DWORD w, DWORD h, int xs, int ys, UINT start,
                                         UINT lines, const void *bits, const BITMAPINFO *bi, UINT use)
{
    if (g_log) { char a[32] = ""; wlog("gdi SetDIBitsToDevice to %s %d,%d %lux%lu", dc_target(d, a, sizeof(a)), xd, yd, w, h); }
    return real_SetDIBitsToDevice(d, xd, yd, w, h, xs, ys, start, lines, bits, bi, use);
}

/* Repaint-request logging (diagnostics only). */
static BOOL (WINAPI *real_InvalidateRect)(HWND, const RECT *, BOOL);
static BOOL (WINAPI *real_ValidateRect)(HWND, const RECT *);
static HDC (WINAPI *real_BeginPaint)(HWND, PAINTSTRUCT *);
static BOOL (WINAPI *real_ScrollDC)(HDC, int, int, const RECT *, const RECT *, HRGN, RECT *);
static BOOL (WINAPI *real_UpdateWindow)(HWND);

static const char *wnd_name(HWND h, char *buf, int n)
{
    if (!h) return "NULL(all windows)";
    if (!GetClassNameA(h, buf, n)) return "?";
    return buf;
}

static BOOL WINAPI hook_InvalidateRect(HWND h, const RECT *r, BOOL erase)
{
    if (g_log) {
        char c[32];
        if (r) wlog("InvalidateRect %s %ld,%ld-%ld,%ld erase=%d", wnd_name(h, c, 32), r->left, r->top, r->right, r->bottom, erase);
        else wlog("InvalidateRect %s whole erase=%d", wnd_name(h, c, 32), erase);
    }
    return real_InvalidateRect(h, r, erase);
}

static BOOL WINAPI hook_ValidateRect(HWND h, const RECT *r)
{
    if (g_log) { char c[32]; wlog("ValidateRect %s %s", wnd_name(h, c, 32), r ? "rect" : "whole"); }
    return real_ValidateRect(h, r);
}

static BOOL (WINAPI *real_EndPaint)(HWND, const PAINTSTRUCT *);

static HDC WINAPI hook_BeginPaint(HWND h, PAINTSTRUCT *ps)
{
    HDC dc = real_BeginPaint(h, ps);
    g_in_paint++;
    if (g_log && ps) { char c[32]; wlog("BeginPaint %s %ld,%ld-%ld,%ld", wnd_name(h, c, 32), ps->rcPaint.left, ps->rcPaint.top, ps->rcPaint.right, ps->rcPaint.bottom); }
    return dc;
}

static BOOL WINAPI hook_EndPaint(HWND h, const PAINTSTRUCT *ps)
{
    if (g_in_paint > 0) g_in_paint--;
    return real_EndPaint(h, ps);
}

static BOOL WINAPI hook_ScrollDC(HDC dc, int dx, int dy, const RECT *rs, const RECT *rc, HRGN rgn, RECT *ru)
{
    if (g_log) { char a[32]; wlog("ScrollDC %s dx=%d dy=%d", dc_target(dc, a, 32), dx, dy); }
    return real_ScrollDC(dc, dx, dy, rs, rc, rgn, ru);
}

static BOOL WINAPI hook_UpdateWindow(HWND h)
{
    if (g_log) { char c[32]; wlog("UpdateWindow %s", wnd_name(h, c, 32)); }
    return real_UpdateWindow(h);
}

/* ---- disc folder as CD (for Wine / Winlator on Android) -----------------
 * Wine can't mount ISO images, so the Android package ships the disc as a
 * plain folder. With [Disc] FakeCD=1 the drive holding that folder answers
 * "CD-ROM, label DKDINO" to the game's disc checks, and the game's Data path
 * points into the folder. Off by default (the Windows package mounts an ISO).*/
static int g_fake_cd;
static char g_disc_drive;            /* 'D' etc.; 0 = none */
static UINT (WINAPI *real_GetDriveTypeA)(LPCSTR);
static BOOL (WINAPI *real_GetVolumeInformationA)(LPCSTR, LPSTR, DWORD, LPDWORD, LPDWORD, LPDWORD, LPSTR, DWORD);
static BOOL (WINAPI *real_GetDiskFreeSpaceA)(LPCSTR, LPDWORD, LPDWORD, LPDWORD, LPDWORD);

static char drive_of(LPCSTR path)
{
    char buf[MAX_PATH];
    if (!path) { if (!GetCurrentDirectoryA(MAX_PATH, buf)) return 0; path = buf; }
    if (path[0] && path[1] == ':') {
        char c = path[0];
        return (c >= 'a' && c <= 'z') ? (char)(c - 32) : c;
    }
    return 0;
}

static UINT WINAPI hook_GetDriveTypeA(LPCSTR root)
{
    UINT t = real_GetDriveTypeA(root);
    char d = drive_of(root);
    UINT r = (g_fake_cd && d && d == g_disc_drive) ? DRIVE_CDROM : t;
    if (g_log) wlog("GetDriveType(%s) = %u%s", root ? root : "null", r, r != t ? " (disc folder -> CD-ROM)" : "");
    tlog("GetDriveType(%s) = %u%s", root ? root : "null", r, r != t ? " (disc folder -> CD-ROM)" : "");
    return r;
}

static BOOL WINAPI hook_GetVolumeInformationA(LPCSTR root, LPSTR name, DWORD nlen, LPDWORD serial,
                                              LPDWORD maxlen, LPDWORD flags, LPSTR fs, DWORD fslen)
{
    BOOL ok = real_GetVolumeInformationA(root, name, nlen, serial, maxlen, flags, fs, fslen);
    char d = drive_of(root);
    if (g_fake_cd && d && d == g_disc_drive) {
        if (name && nlen > 6) lstrcpynA(name, "DKDINO", nlen);
        if (fs && fslen > 4) lstrcpynA(fs, "CDFS", fslen);
        if (!ok) {                                   /* fill the rest sensibly */
            if (serial) *serial = 0x1996D1A0;
            if (maxlen) *maxlen = 110;
            if (flags) *flags = 0;
            ok = TRUE;
        }
    }
    if (g_log) wlog("GetVolumeInformation(%s) ok=%d label=%s", root ? root : "null", ok, name && ok ? name : "-");
    tlog("GetVolumeInformation(%s) ok=%d label=%s", root ? root : "null", ok, name && ok ? name : "-");
    return ok;
}

static BOOL WINAPI hook_GetDiskFreeSpaceA(LPCSTR root, LPDWORD spc, LPDWORD bps, LPDWORD freec, LPDWORD total)
{
    BOOL ok = real_GetDiskFreeSpaceA(root, spc, bps, freec, total);
    if (g_log) wlog("GetDiskFreeSpace(%s) ok=%d", root ? root : "null", ok);
    return ok;
}

/* ---- start-up trace (for troubleshooting under Wine / Winlator) ---------
 * With [Debug] Trace=1, writes startup.log next to this DLL: disc checks,
 * video (MCI) commands, sound device opens and any message boxes, so a
 * start-up that stalls can be diagnosed from the log alone.               */
static int g_trace;
static void tlog(const char *fmt, ...)
{
    static LONG lines;
    static DWORD t0;
    char path[MAX_PATH];
    FILE *f;
    va_list ap;
    if (!g_trace || InterlockedIncrement(&lines) > 4000) return;
    if (!t0) t0 = GetTickCount();
    path_next_to_dll(path, "startup.log");
    f = fopen(path, "a");
    if (!f) return;
    fprintf(f, "%7.2fs ", (GetTickCount() - t0) / 1000.0);
    va_start(ap, fmt); vfprintf(f, fmt, ap); va_end(ap);
    fputc('\n', f);
    fclose(f);
}

static const char *safe_str(const char *s) { return (s && !IsBadStringPtrA(s, 260)) ? s : "?"; }

static MCIERROR (WINAPI *real_mciSendCommandA)(MCIDEVICEID, UINT, DWORD_PTR, DWORD_PTR);
static MCIERROR (WINAPI *real_mciSendStringA)(LPCSTR, LPSTR, UINT, HWND);
static MMRESULT (WINAPI *real_waveOutOpen)(LPHWAVEOUT, UINT, LPCWAVEFORMATEX, DWORD_PTR, DWORD_PTR, DWORD);
static MMRESULT (WINAPI *real_waveOutWrite)(HWAVEOUT, LPWAVEHDR, UINT);
static MMRESULT (WINAPI *real_waveOutReset)(HWAVEOUT);
static MMRESULT (WINAPI *real_waveOutClose)(HWAVEOUT);
static int (WINAPI *real_MessageBoxA)(HWND, LPCSTR, LPCSTR, UINT);
static INT_PTR (WINAPI *real_DialogBoxParamA)(HINSTANCE, LPCSTR, HWND, DLGPROC, LPARAM);
static HWND (WINAPI *real_CreateWindowExA)(DWORD, LPCSTR, LPCSTR, DWORD, int, int, int, int, HWND, HMENU, HINSTANCE, LPVOID);

/* ---- converted videos ----------------------------------------------------
 * The original disc's videos use Indeo, which modern Windows can't decode.
 * The launchers convert them (once, with the bundled ffmpeg) into
 * Game\DKCODE\VIDEOS, keeping the disc's folder structure. When the game
 * opens a video from the disc and a converted copy exists, it gets the copy.
 * The disc itself is never changed. [Video] Redirect=0 turns this off.     */
static int g_video_redirect = 1;

static int video_redirect(const char *file, char *out)
{
    char ini[MAX_PATH], data[MAX_PATH], alt[MAX_PATH];
    size_t n;
    if (!g_video_redirect || !file || IsBadStringPtrA(file, MAX_PATH)) return 0;
    path_next_to_dll(ini, "Dinosaur Hunter.ini");
    GetPrivateProfileStringA("Directory", "Data", "", data, sizeof(data), ini);
    n = strlen(data);
    if (!n) return 0;
    if (data[n - 1] != '\\') { data[n++] = '\\'; data[n] = 0; }
    if (_strnicmp(file, data, n) != 0) return 0;          /* not a file on the disc */
    path_next_to_dll(alt, "VIDEOS\\");
    if (strlen(alt) + strlen(file + n) >= MAX_PATH) return 0;
    strcat(alt, file + n);
    if (GetFileAttributesA(alt) == INVALID_FILE_ATTRIBUTES) return 0;
    strcpy(out, alt);
    return 1;
}

static MCIERROR WINAPI hook_mciSendCommandA(MCIDEVICEID id, UINT msg, DWORD_PTR flags, DWORD_PTR param)
{
    MCIERROR r;
    char extra[400] = "";
    if (msg == MCI_OPEN && param && (flags & MCI_OPEN_ELEMENT)) {
        MCI_OPEN_PARMSA *p = (MCI_OPEN_PARMSA *)param;
        char alt[MAX_PATH];
        if (video_redirect(p->lpstrElementName, alt)) {
            LPCSTR orig = p->lpstrElementName;
            tlog("video: %s -> converted copy %s", safe_str(orig), alt);
            p->lpstrElementName = alt;
            r = real_mciSendCommandA(id, msg, flags, param);
            p->lpstrElementName = orig;
            tlog("   -> %lu (device %u)", (unsigned long)r, r ? 0 : p->wDeviceID);
            return r;
        }
    }
    if (msg == MCI_OPEN && param) {
        MCI_OPEN_PARMSA *p = (MCI_OPEN_PARMSA *)param;
        char type[64];
        if (flags & MCI_OPEN_TYPE_ID) wsprintfA(type, "#%lu", (unsigned long)(DWORD_PTR)p->lpstrDeviceType);
        else lstrcpynA(type, (flags & MCI_OPEN_TYPE) ? safe_str(p->lpstrDeviceType) : "-", sizeof(type));
        wsprintfA(extra, " type=%s file=%s", type, (flags & MCI_OPEN_ELEMENT) ? safe_str(p->lpstrElementName) : "-");
    }
    if (msg == MCI_WINDOW || msg == MCI_PUT || msg == MCI_WHERE) {
        tlog("mciSendCommand(dev=%u, msg=0x%X, flags=0x%lX)", id, msg, (unsigned long)flags);
        r = real_mciSendCommandA(id, msg, flags, param);
        tlog("   -> %lu", (unsigned long)r);
        return r;
    }
    if (msg == MCI_STATUS && param) {    /* polled constantly: log only changes */
        static DWORD last_item, last_val, last_r = 1;
        MCI_STATUS_PARMS *p = (MCI_STATUS_PARMS *)param;
        r = real_mciSendCommandA(id, msg, flags, param);
        if (r != last_r || p->dwItem != last_item || (DWORD)p->dwReturn != last_val)
            tlog("mciSendCommand(dev=%u, STATUS item %lu) -> %lu (value %lu)", id, (unsigned long)p->dwItem,
                 (unsigned long)r, (unsigned long)p->dwReturn);
        last_r = r; last_item = p->dwItem; last_val = (DWORD)p->dwReturn;
        return r;
    }
    tlog("mciSendCommand(dev=%u, msg=0x%X, flags=0x%lX)%s ...", id, msg, (unsigned long)flags, extra);
    r = real_mciSendCommandA(id, msg, flags, param);
    if (msg == MCI_OPEN && param && !r) tlog("   -> 0 (device %u)", ((MCI_OPEN_PARMSA *)param)->wDeviceID);
    else if (msg == MCI_STATUS && param && !r) tlog("   -> 0 (item %lu = %lu)", (unsigned long)((MCI_STATUS_PARMS *)param)->dwItem, (unsigned long)((MCI_STATUS_PARMS *)param)->dwReturn);
    else tlog("   -> %lu", (unsigned long)r);
    return r;
}

static MCIERROR WINAPI hook_mciSendStringA(LPCSTR cmd, LPSTR ret, UINT len, HWND cb)
{
    MCIERROR r;
    tlog("mciSendString(\"%s\") ...", safe_str(cmd));
    r = real_mciSendStringA(cmd, ret, len, cb);
    tlog("   -> %lu \"%s\"", (unsigned long)r, (ret && len && !r) ? ret : "");
    return r;
}

/* ---- sound watchdog ------------------------------------------------------
 * The game plays sound in small chunks and waits for the sound driver to
 * report each chunk finished (MM_WOM_DONE to its window) before going on -
 * the DK logo screen waits for its jingle like this. If a sound driver never
 * reports back (seen under Winlator), the game would wait forever. With
 * [Sound] Watchdog=1, a device whose chunks are overdue by WATCHDOG_MS is
 * switched to "silent": its chunks are reported finished on schedule
 * without being played, so the game keeps going (just without that sound).
 * [Sound] SimulateStall=1 never passes chunks to the driver (for testing). */
#define WHDR_DONE_ 0x00000001
#define WHDR_INQUEUE_ 0x00000010
#define MM_WOM_DONE_ 0x3BD
#define CALLBACK_WINDOW_ 0x00010000
#define CALLBACK_TYPEMASK_ 0x00070000
#define WAVE_FORMAT_QUERY_ 0x0001
#define WATCHDOG_MS 2500
#define MAX_WO 8
#define MAX_PEND 128

static int g_watchdog, g_sim_stall, g_driver_stalled;
static MMRESULT (WINAPI *real_waveOutUnprepareHeader)(HWAVEOUT, LPWAVEHDR, UINT);
static struct wo {
    HWAVEOUT h; HWND cb; DWORD bps; int silent; DWORD next_due; DWORD paused_at;
    int n; struct { LPWAVEHDR hdr; DWORD due; } p[MAX_PEND];
} g_wo[MAX_WO];
static UINT_PTR g_wd_timer;

static struct wo *wo_find(HWAVEOUT h)
{
    int i;
    if (!h) return NULL;
    for (i = 0; i < MAX_WO; i++) if (g_wo[i].h == h) return &g_wo[i];
    return NULL;
}

static void wo_remove(struct wo *w, int i)
{
    w->p[i] = w->p[--w->n];
}

static void wo_forget(struct wo *w, LPWAVEHDR hdr)
{
    int i;
    for (i = w->n - 1; i >= 0; i--) if (w->p[i].hdr == hdr) wo_remove(w, i);
}

/* Report one chunk finished, as the driver would. */
static void wo_complete(struct wo *w, LPWAVEHDR hdr)
{
    if (!IsBadWritePtr(hdr, sizeof(WAVEHDR))) {
        hdr->dwFlags &= ~WHDR_INQUEUE_;
        hdr->dwFlags |= WHDR_DONE_;
    }
    PostMessageA(w->cb, MM_WOM_DONE_, (WPARAM)w->h, (LPARAM)hdr);
}

static int hdr_done(LPWAVEHDR hdr)
{
    return IsBadReadPtr(hdr, sizeof(WAVEHDR)) || (hdr->dwFlags & WHDR_DONE_);
}

static void px_tick(void);
static void CALLBACK watchdog_tick(HWND hw, UINT msg, UINT_PTR id, DWORD t)
{
    DWORD now = GetTickCount();
    int i, j;
    (void)hw; (void)msg; (void)id; (void)t;
    px_tick();
    for (i = 0; i < MAX_WO; i++) {
        struct wo *w = &g_wo[i];
        if (!w->h || w->paused_at) continue;
        if (w->silent == 1) {                /* finish chunks on schedule */
            for (j = w->n - 1; j >= 0; j--)
                if ((int)(now - w->p[j].due) >= 0) { LPWAVEHDR hd = w->p[j].hdr; wo_remove(w, j); wo_complete(w, hd); }
            continue;
        }
        for (j = w->n - 1; j >= 0; j--) if (hdr_done(w->p[j].hdr)) wo_remove(w, j);
        for (j = 0; j < w->n; j++) {
            if ((int)(now - w->p[j].due) > WATCHDOG_MS) {
                tlog("sound watchdog: the sound driver stopped reporting back (%d chunks overdue) - continuing without this sound", w->n);
                if (g_log) wlog("sound watchdog: device stalled, switching to silent");
                w->silent = 1;
                g_driver_stalled = 1;                /* later sounds go silent straight away */
                real_waveOutReset(w->h);        /* lets a working driver hand chunks back */
                for (j = w->n - 1; j >= 0; j--) {
                    LPWAVEHDR hd = w->p[j].hdr;
                    wo_remove(w, j);
                    if (!hdr_done(hd)) wo_complete(w, hd);
                }
                w->next_due = now;
                break;
            }
        }
    }
}

/* ---- sound fallback device ----------------------------------------------
 * Under Winlator (Wine 10.10) opening the sound device the game's way fails
 * with "not enabled" (3), and the game then waits forever on the DK logo.
 * When that happens (and [Sound] Fallback=1), the game gets one of these
 * stand-in devices instead. It opens the real device itself with its own
 * callback, trying the game's format first, then standard 16-bit formats
 * (converting the game's sound), and plays silently if nothing works. It
 * tells the game's window that each chunk has finished, just like a real
 * device. [Sound] FallbackTest=1/2/3 forces it on (1 = same format,
 * 2 = converted format, 3 = silent) for testing on Windows.               */
#define WHDR_PREPARED_ 0x00000002
#define MM_WOM_OPEN_ 0x3BB
#define MM_WOM_CLOSE_ 0x3BC
#define CALLBACK_FUNCTION_ 0x00030000
#define WAVERR_STILLPLAYING_ 33
#define MAX_PX 8
#define PX_SLOTS 64

static int g_fallback, g_fallback_test;
static MMRESULT (WINAPI *real_waveOutPrepareHeader)(HWAVEOUT, LPWAVEHDR, UINT);
static MMRESULT (WINAPI *real_waveOutGetVolume)(HWAVEOUT, LPDWORD);
static MMRESULT (WINAPI *real_waveOutSetVolume)(HWAVEOUT, DWORD);

static struct px {
    int used, silent, convert;
    HWND cb;
    WAVEFORMATEX src, dst;
    HWAVEOUT real;
    DWORD next_due, paused_at, volume;
    struct { LPWAVEHDR game; WAVEHDR inner; char *buf; volatile LONG busy; DWORD due; } s[PX_SLOTS];
} g_px[MAX_PX];       /* a stand-in device's handle is the address of its entry */

static struct px *px_find(HWAVEOUT h)
{
    struct px *p = (struct px *)h;
    if (p >= &g_px[0] && p < &g_px[MAX_PX] && p->used) return p;
    return NULL;
}

/* Called by the sound system (on its own thread) when a chunk has played. */
static void CALLBACK px_callback(HWAVEOUT hw, UINT msg, DWORD_PTR inst, DWORD_PTR p1, DWORD_PTR p2)
{
    struct px *p = &g_px[inst];
    WAVEHDR *in = (WAVEHDR *)p1;
    DWORD i;
    (void)hw; (void)p2;
    if (msg != MM_WOM_DONE_ || !in || inst >= MAX_PX) return;
    i = (DWORD)in->dwUser;
    if (i >= PX_SLOTS || p->s[i].busy != 1) return;
    p->s[i].game->dwFlags = (p->s[i].game->dwFlags & ~WHDR_INQUEUE_) | WHDR_DONE_;
    InterlockedExchange(&p->s[i].busy, 2);
    PostMessageA(p->cb, MM_WOM_DONE_, (WPARAM)p, (LPARAM)p->s[i].game);
}

/* Tidy up chunks that have finished playing (on the game's thread). */
static void px_reap(struct px *p)
{
    int i;
    for (i = 0; i < PX_SLOTS; i++) if (p->s[i].busy == 2) {
        if (p->real) real_waveOutUnprepareHeader(p->real, &p->s[i].inner, sizeof(WAVEHDR));
        free(p->s[i].buf);
        p->s[i].buf = NULL;
        p->s[i].game = NULL;
        InterlockedExchange(&p->s[i].busy, 0);
    }
}

static void px_finish(struct px *p, int i)  /* silent chunk finished */
{
    LPWAVEHDR g = p->s[i].game;
    p->s[i].game = NULL;
    InterlockedExchange(&p->s[i].busy, 0);
    if (g) {
        g->dwFlags = (g->dwFlags & ~WHDR_INQUEUE_) | WHDR_DONE_;
        PostMessageA(p->cb, MM_WOM_DONE_, (WPARAM)p, (LPARAM)g);
    }
}

static void px_tick(void)
{
    DWORD now = GetTickCount();
    int k, i;
    for (k = 0; k < MAX_PX; k++) {
        struct px *p = &g_px[k];
        if (!p->used) continue;
        px_reap(p);
        if (!p->silent || p->paused_at) continue;
        for (i = 0; i < PX_SLOTS; i++)
            if (p->s[i].busy == 1 && (int)(now - p->s[i].due) >= 0) px_finish(p, i);
    }
}

/* PCM (8/16-bit, mono/stereo, any rate) -> 16-bit PCM in the device's format. */
static char *px_convert(struct px *p, const char *in, DWORD len, DWORD *outlen)
{
    const WAVEFORMATEX *s = &p->src, *d = &p->dst;
    int sb = s->wBitsPerSample / 8, sc = s->nChannels, dc = d->nChannels;
    DWORD fin = (sb && sc) ? len / (sb * sc) : 0;
    DWORD fout = (DWORD)(((unsigned __int64)fin * d->nSamplesPerSec) / s->nSamplesPerSec);
    short *o;
    DWORD k;
    *outlen = fout * dc * 2;
    o = (short *)malloc(*outlen ? *outlen : 2);
    if (!o) return NULL;
    for (k = 0; k < fout; k++) {
        DWORD i = (DWORD)(((unsigned __int64)k * s->nSamplesPerSec) / d->nSamplesPerSec);
        int c, v[2];
        if (i >= fin) i = fin - 1;
        for (c = 0; c < sc && c < 2; c++) {
            const char *q = in + (i * sc + c) * sb;
            v[c] = sb == 1 ? ((int)(unsigned char)*q - 128) << 8 : *(const short *)q;
        }
        if (sc == 1) v[1] = v[0];
        if (dc == 1) o[k] = (short)(sc == 2 ? (v[0] + v[1]) / 2 : v[0]);
        else { o[k * 2] = (short)v[0]; o[k * 2 + 1] = (short)v[1]; }
    }
    return (char *)o;
}

static void pcm16(WAVEFORMATEX *f, DWORD rate, WORD ch)
{
    ZeroMemory(f, sizeof(*f));
    f->wFormatTag = 1; f->nChannels = ch; f->nSamplesPerSec = rate; f->wBitsPerSample = 16;
    f->nBlockAlign = (WORD)(ch * 2); f->nAvgBytesPerSec = rate * ch * 2;
}

static MMRESULT px_open(LPHWAVEOUT h, UINT dev, LPCWAVEFORMATEX fmt, HWND cb)
{
    int k, n;
    struct px *p = NULL;
    WAVEFORMATEX cand[5];
    for (k = 0; k < MAX_PX; k++) if (!g_px[k].used) { p = &g_px[k]; break; }
    if (!p) return 4;                        /* MMSYSERR_ALLOCATED */
    ZeroMemory(p, sizeof(*p));
    p->used = 1;
    p->cb = cb;
    p->src = *fmt;
    p->volume = 0xFFFFFFFF;
    if (!p->src.nAvgBytesPerSec) p->src.nAvgBytesPerSec = 11025;

    /* 1: the game's own format, but with our callback */
    if (g_fallback_test <= 1 &&
        real_waveOutOpen(&p->real, dev, fmt, (DWORD_PTR)px_callback, (DWORD_PTR)(p - g_px), CALLBACK_FUNCTION_) == 0) {
        p->dst = p->src;
        tlog("sound fallback: opened the game's format (%luHz %ubit %uch) with a callback function",
             (unsigned long)fmt->nSamplesPerSec, fmt->wBitsPerSample, fmt->nChannels);
    } else {
        p->real = NULL;
        /* 2: standard 16-bit formats, converting the game's PCM sound */
        n = 0;
        if (fmt->wFormatTag == 1 && (fmt->wBitsPerSample == 8 || fmt->wBitsPerSample == 16) &&
            (fmt->nChannels == 1 || fmt->nChannels == 2) && fmt->nSamplesPerSec && g_fallback_test <= 2) {
            pcm16(&cand[n++], fmt->nSamplesPerSec, fmt->nChannels);
            pcm16(&cand[n++], 22050, 1);
            pcm16(&cand[n++], 44100, 2);
            pcm16(&cand[n++], 48000, 2);
        }
        for (k = 0; k < n; k++) {
            MMRESULT r = real_waveOutOpen(&p->real, (UINT)-1 /* WAVE_MAPPER */, &cand[k], (DWORD_PTR)px_callback,
                                          (DWORD_PTR)(p - g_px), CALLBACK_FUNCTION_);
            tlog("sound fallback: try %luHz 16bit %uch -> %u", (unsigned long)cand[k].nSamplesPerSec, cand[k].nChannels, r);
            if (r == 0) { p->dst = cand[k]; p->convert = 1; break; }
            p->real = NULL;
        }
        if (!p->real) {
            p->silent = 1;
            tlog("sound fallback: no sound format works - this sound plays silently");
        }
    }
    p->next_due = GetTickCount();
    if (!g_wd_timer) g_wd_timer = SetTimer(NULL, 0, 100, watchdog_tick);
    *h = (HWAVEOUT)p;
    PostMessageA(cb, MM_WOM_OPEN_, (WPARAM)p, 0);
    return 0;
}

static MMRESULT px_write(struct px *p, LPWAVEHDR g)
{
    int i;
    DWORD now = GetTickCount(), dur;
    px_reap(p);
    for (i = 0; i < PX_SLOTS; i++) if (p->s[i].busy == 0) break;
    if (i == PX_SLOTS) return 7;             /* MMSYSERR_NOMEM */
    g->dwFlags = (g->dwFlags & ~WHDR_DONE_) | WHDR_INQUEUE_;
    p->s[i].game = g;
    dur = (DWORD)((g->dwBufferLength * 1000.0) / p->src.nAvgBytesPerSec);
    if ((int)(now - p->next_due) > 0) p->next_due = now;
    p->next_due += dur;
    p->s[i].due = p->next_due;
    if (!p->silent) {
        DWORD n = g->dwBufferLength;
        char *b = p->convert ? px_convert(p, g->lpData, g->dwBufferLength, &n) : (char *)malloc(n ? n : 1);
        if (b && !p->convert) memcpy(b, g->lpData, n);
        if (b) {
            WAVEHDR *in = &p->s[i].inner;
            ZeroMemory(in, sizeof(*in));
            in->lpData = b; in->dwBufferLength = n; in->dwUser = i;
            p->s[i].buf = b;
            InterlockedExchange(&p->s[i].busy, 1);
            if (real_waveOutPrepareHeader(p->real, in, sizeof(WAVEHDR)) == 0 &&
                real_waveOutWrite(p->real, in, sizeof(WAVEHDR)) == 0)
                return 0;
            free(b);
            p->s[i].buf = NULL;
        }
        tlog("sound fallback: the sound device refused a chunk - continuing silently");
        p->silent = 1;
    }
    InterlockedExchange(&p->s[i].busy, 1);   /* silent: finished on schedule */
    return 0;
}

static MMRESULT px_reset(struct px *p)
{
    int i;
    p->paused_at = 0;
    if (p->real) real_waveOutReset(p->real);
    px_reap(p);
    for (i = 0; i < PX_SLOTS; i++)            /* silent chunks (and any stragglers) */
        if (p->s[i].busy == 1 && !p->s[i].buf) px_finish(p, i);
    p->next_due = GetTickCount();
    return 0;
}

static MMRESULT px_close(struct px *p)
{
    int tries, i, left;
    px_reset(p);
    for (tries = 0; tries < 50; tries++) {    /* let the last callbacks arrive */
        px_reap(p);
        for (left = 0, i = 0; i < PX_SLOTS; i++) if (p->s[i].busy) left++;
        if (!left) break;
        Sleep(10);
    }
    if (p->real) real_waveOutClose(p->real);
    PostMessageA(p->cb, MM_WOM_CLOSE_, (WPARAM)p, 0);
    p->used = 0;
    return 0;
}

static MMRESULT WINAPI hook_waveOutPrepareHeader(HWAVEOUT h, LPWAVEHDR hdr, UINT sz)
{
    if (px_find(h)) {
        if (!hdr) return 11;                 /* MMSYSERR_INVALPARAM */
        hdr->dwFlags = (hdr->dwFlags & ~WHDR_DONE_) | WHDR_PREPARED_;
        return 0;
    }
    return real_waveOutPrepareHeader(h, hdr, sz);
}

static MMRESULT WINAPI hook_waveOutGetVolume(HWAVEOUT h, LPDWORD v)
{
    struct px *p = px_find(h);
    if (p) {
        if (p->real) return real_waveOutGetVolume(p->real, v);
        if (v) *v = p->volume;
        return 0;
    }
    return real_waveOutGetVolume(h, v);
}

static MMRESULT WINAPI hook_waveOutSetVolume(HWAVEOUT h, DWORD v)
{
    struct px *p = px_find(h);
    if (p) {
        p->volume = v;
        return p->real ? real_waveOutSetVolume(p->real, v) : 0;
    }
    return real_waveOutSetVolume(h, v);
}

static LONG g_wave_writes;
static MMRESULT WINAPI hook_waveOutOpen(LPHWAVEOUT h, UINT dev, LPCWAVEFORMATEX fmt, DWORD_PTR cb, DWORD_PTR inst, DWORD fl)
{
    MMRESULT r = real_waveOutOpen(h, dev, fmt, cb, inst, fl);
    int windowed = h && fmt && cb && !(fl & WAVE_FORMAT_QUERY_) && (fl & CALLBACK_TYPEMASK_) == CALLBACK_WINDOW_;
    if (fmt) tlog("waveOutOpen(dev=%d, fmt=%u %luHz %uch %ubit, flags=0x%lX) -> %u",
                  (int)dev, fmt->wFormatTag, (unsigned long)fmt->nSamplesPerSec, fmt->nChannels,
                  fmt->wBitsPerSample, (unsigned long)fl, r);
    if (g_fallback && windowed && (r || g_fallback_test)) {
        if (!r) real_waveOutClose(*h);       /* test mode: pretend it failed */
        r = px_open(h, dev, fmt, (HWND)cb);
        tlog("   -> sound fallback device %s", r ? "FAILED" : "in use");
        return r;
    }
    if (g_watchdog && !r && h && fmt && !(fl & WAVE_FORMAT_QUERY_) && (fl & CALLBACK_TYPEMASK_) == CALLBACK_WINDOW_ && cb) {
        int i;
        for (i = 0; i < MAX_WO; i++) if (!g_wo[i].h) {
            ZeroMemory(&g_wo[i], sizeof(g_wo[i]));
            g_wo[i].h = *h;
            g_wo[i].cb = (HWND)cb;
            g_wo[i].bps = fmt->nAvgBytesPerSec ? fmt->nAvgBytesPerSec : 11025;
            g_wo[i].silent = g_driver_stalled ? 1 : g_sim_stall ? 2 : 0;   /* 2 = pretend-stalled (test) */
            break;
        }
        if (!g_wd_timer) g_wd_timer = SetTimer(NULL, 0, 100, watchdog_tick);
    }
    return r;
}

static MMRESULT WINAPI hook_waveOutWrite(HWAVEOUT h, LPWAVEHDR hdr, UINT sz)
{
    MMRESULT r;
    LONG n = InterlockedIncrement(&g_wave_writes);
    struct wo *w = g_watchdog ? wo_find(h) : NULL;
    struct px *p = px_find(h);
    DWORD now = GetTickCount(), dur = 0;
    if (p) {
        r = hdr ? px_write(p, hdr) : 11;
        if (n <= 3 || n % 100 == 0 || r) tlog("waveOutWrite #%ld (%lu bytes, fallback%s) -> %u", n,
                                             hdr ? (unsigned long)hdr->dwBufferLength : 0UL, p->silent ? ", silent" : "", r);
        return r;
    }
    if (w && hdr) {
        wo_forget(w, hdr);
        dur = (DWORD)((hdr->dwBufferLength * 1000.0) / w->bps);
        if ((int)(now - w->next_due) > 0) w->next_due = now;
        w->next_due += dur;
    }
    if (w && w->silent == 1) {               /* silent: don't play, finish on schedule */
        hdr->dwFlags &= ~WHDR_DONE_;
        hdr->dwFlags |= WHDR_INQUEUE_;
        r = 0;
    } else if (w && w->silent == 2) {        /* SimulateStall: accept, never finish */
        hdr->dwFlags &= ~WHDR_DONE_;
        hdr->dwFlags |= WHDR_INQUEUE_;
        r = 0;
    } else {
        r = real_waveOutWrite(h, hdr, sz);
    }
    if (w && hdr && !r && w->n < MAX_PEND) {
        w->p[w->n].hdr = hdr;
        w->p[w->n].due = w->next_due;
        w->n++;
    }
    if (n <= 3 || n % 100 == 0 || r) tlog("waveOutWrite #%ld (%lu bytes) -> %u", n, hdr ? (unsigned long)hdr->dwBufferLength : 0UL, r);
    return r;
}

static MMRESULT WINAPI hook_waveOutUnprepareHeader(HWAVEOUT h, LPWAVEHDR hdr, UINT sz)
{
    struct wo *w = g_watchdog ? wo_find(h) : NULL;
    if (px_find(h)) {
        if (!hdr) return 11;
        if (hdr->dwFlags & WHDR_INQUEUE_) return WAVERR_STILLPLAYING_;
        hdr->dwFlags &= ~WHDR_PREPARED_;
        return 0;
    }
    if (w) {
        wo_forget(w, hdr);
        if (w->silent && hdr) hdr->dwFlags &= ~WHDR_INQUEUE_;
    }
    return real_waveOutUnprepareHeader(h, hdr, sz);
}

/* Paused sound isn't overdue: stop the clock while paused. */
static MMRESULT (WINAPI *real_waveOutPause)(HWAVEOUT);
static MMRESULT (WINAPI *real_waveOutRestart)(HWAVEOUT);
static MMRESULT WINAPI hook_waveOutPause(HWAVEOUT h)
{
    struct wo *w = g_watchdog ? wo_find(h) : NULL;
    struct px *p = px_find(h);
    if (p) {
        if (!p->paused_at) p->paused_at = GetTickCount() | 1;
        return p->real ? real_waveOutPause(p->real) : 0;
    }
    if (w && !w->paused_at) w->paused_at = GetTickCount() | 1;
    return (w && w->silent) ? 0 : real_waveOutPause(h);
}

static MMRESULT WINAPI hook_waveOutRestart(HWAVEOUT h)
{
    struct wo *w = g_watchdog ? wo_find(h) : NULL;
    struct px *p = px_find(h);
    if (p) {
        if (p->paused_at) {
            DWORD gap = GetTickCount() - p->paused_at;
            int i;
            for (i = 0; i < PX_SLOTS; i++) if (p->s[i].busy == 1) p->s[i].due += gap;
            p->next_due += gap;
            p->paused_at = 0;
        }
        return p->real ? real_waveOutRestart(p->real) : 0;
    }
    if (w && w->paused_at) {
        DWORD gap = GetTickCount() - w->paused_at;
        int i;
        for (i = 0; i < w->n; i++) w->p[i].due += gap;
        w->next_due += gap;
        w->paused_at = 0;
    }
    return (w && w->silent) ? 0 : real_waveOutRestart(h);
}

static MMRESULT WINAPI hook_waveOutReset(HWAVEOUT h)
{
    struct wo *w = g_watchdog ? wo_find(h) : NULL;
    struct px *p = px_find(h);
    MMRESULT r;
    if (p) { tlog("waveOutReset (fallback)"); return px_reset(p); }
    r = real_waveOutReset(h);
    if (w) w->paused_at = 0;
    if (w && w->silent) {                    /* hand back everything at once */
        while (w->n) { LPWAVEHDR hd = w->p[w->n - 1].hdr; wo_remove(w, w->n - 1); wo_complete(w, hd); }
        w->next_due = GetTickCount();
        r = 0;
    }
    tlog("waveOutReset -> %u", r);
    return r;
}

static MMRESULT WINAPI hook_waveOutClose(HWAVEOUT h)
{
    struct wo *w = g_watchdog ? wo_find(h) : NULL;
    struct px *p = px_find(h);
    MMRESULT r;
    if (p) { tlog("waveOutClose (fallback, after %ld writes)", g_wave_writes); return px_close(p); }
    if (w) {
        if (w->silent) real_waveOutReset(h);
        w->h = NULL;
    }
    r = real_waveOutClose(h);
    tlog("waveOutClose -> %u (after %ld writes)", r, g_wave_writes);
    return r;
}

/* Message boxes: logged, and kept in front (under Winlator a box can open
   behind the game's window, which then looks frozen). */
static int WINAPI hook_MessageBoxA(HWND w, LPCSTR text, LPCSTR cap, UINT type)
{
    int r;
    tlog("MessageBox \"%s\": %s", safe_str(cap), safe_str(text));
    r = real_MessageBoxA(w, text, cap, type | MB_TOPMOST | MB_SETFOREGROUND);
    tlog("   -> answered %d", r);
    return r;
}

static INT_PTR WINAPI hook_DialogBoxParamA(HINSTANCE i, LPCSTR tmpl, HWND w, DLGPROC proc, LPARAM lp)
{
    INT_PTR r;
    if (HIWORD((DWORD_PTR)tmpl)) tlog("DialogBox %s", safe_str(tmpl));
    else tlog("DialogBox #%u", LOWORD((DWORD_PTR)tmpl));
    r = real_DialogBoxParamA(i, tmpl, w, proc, lp);
    tlog("   -> closed %ld", (long)r);
    return r;
}

static HWND WINAPI hook_CreateWindowExA(DWORD ex, LPCSTR cls, LPCSTR title, DWORD st, int x, int y, int w, int h,
                                        HWND parent, HMENU menu, HINSTANCE inst, LPVOID lp)
{
    HWND r = real_CreateWindowExA(ex, cls, title, st, x, y, w, h, parent, menu, inst, lp);
    tlog("CreateWindow class=%s title=%s %dx%d -> %s", HIWORD((DWORD_PTR)cls) ? safe_str(cls) : "#atom",
         HIWORD((DWORD_PTR)title) ? safe_str(title) : "", w, h, r ? "ok" : "FAILED");
    return r;
}

/* Replace one imported function in the game exe's import table. */
static void *patch_import(const char *dll, const char *func, void *hook)
{
    BYTE *base = (BYTE *)GetModuleHandleA(NULL);
    IMAGE_NT_HEADERS *nt = (IMAGE_NT_HEADERS *)(base + ((IMAGE_DOS_HEADER *)base)->e_lfanew);
    IMAGE_DATA_DIRECTORY dir = nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT];
    IMAGE_IMPORT_DESCRIPTOR *imp = (IMAGE_IMPORT_DESCRIPTOR *)(base + dir.VirtualAddress);
    for (; dir.VirtualAddress && imp->Name; imp++) {
        IMAGE_THUNK_DATA *names, *addrs;
        if (_stricmp((char *)(base + imp->Name), dll) != 0) continue;
        names = (IMAGE_THUNK_DATA *)(base + (imp->OriginalFirstThunk ? imp->OriginalFirstThunk : imp->FirstThunk));
        addrs = (IMAGE_THUNK_DATA *)(base + imp->FirstThunk);
        for (; names->u1.AddressOfData; names++, addrs++) {
            IMAGE_IMPORT_BY_NAME *n;
            DWORD old;
            void *orig;
            if (names->u1.Ordinal & IMAGE_ORDINAL_FLAG) continue;
            n = (IMAGE_IMPORT_BY_NAME *)(base + names->u1.AddressOfData);
            if (strcmp((char *)n->Name, func) != 0) continue;
            orig = (void *)addrs->u1.Function;
            VirtualProtect(&addrs->u1.Function, sizeof(void *), PAGE_READWRITE, &old);
            addrs->u1.Function = (DWORD_PTR)hook;
            VirtualProtect(&addrs->u1.Function, sizeof(void *), old, &old);
            return orig;
        }
    }
    return NULL;
}

/* Disc hooks: installed when the DLL loads, before any game code runs
   (the game checks for its CD before it first uses WinG). */
static void install_disc_hooks(void)
{
    real_GetDriveTypeA = patch_import("KERNEL32.dll", "GetDriveTypeA", hook_GetDriveTypeA);
    real_GetVolumeInformationA = patch_import("KERNEL32.dll", "GetVolumeInformationA", hook_GetVolumeInformationA);
    real_GetDiskFreeSpaceA = patch_import("KERNEL32.dll", "GetDiskFreeSpaceA", hook_GetDiskFreeSpaceA);
    if (!real_GetDriveTypeA) real_GetDriveTypeA = GetDriveTypeA;
    if (!real_GetVolumeInformationA) real_GetVolumeInformationA = GetVolumeInformationA;
    if (!real_GetDiskFreeSpaceA) real_GetDiskFreeSpaceA = GetDiskFreeSpaceA;
    if (g_log) wlog("disc hooks installed (FakeCD=%d drive=%c)", g_fake_cd, g_disc_drive ? g_disc_drive : '-');

    real_MessageBoxA = patch_import("USER32.dll", "MessageBoxA", hook_MessageBoxA);
    if (!real_MessageBoxA) real_MessageBoxA = MessageBoxA;
    /* Video commands: always watched (converted-video redirect; logged with Trace). */
    if (g_trace || g_video_redirect)
        real_mciSendCommandA = patch_import("WINMM.dll", "mciSendCommandA", hook_mciSendCommandA);
    if (g_trace) {
        char exe[MAX_PATH];
        HMODULE nt = GetModuleHandleA("ntdll.dll");
        const char *(CDECL *wine_ver)(void) = nt ? (const char *(CDECL *)(void))GetProcAddress(nt, "wine_get_version") : NULL;
        GetModuleFileNameA(NULL, exe, MAX_PATH);
        tlog("---- start: %s", exe);
        tlog("running on %s %s", wine_ver ? "Wine" : "Windows", wine_ver ? wine_ver() : "");
        tlog("WING32.DLL is ours (FakeCD=%d, disc drive=%c)", g_fake_cd, g_disc_drive ? g_disc_drive : '-');
        tlog("sound watchdog %s%s", g_watchdog ? "on" : "off", g_sim_stall ? " (SimulateStall test mode)" : "");
        real_mciSendStringA = patch_import("WINMM.dll", "mciSendStringA", hook_mciSendStringA);
        real_DialogBoxParamA = patch_import("USER32.dll", "DialogBoxParamA", hook_DialogBoxParamA);
        real_CreateWindowExA = patch_import("USER32.dll", "CreateWindowExA", hook_CreateWindowExA);
        /* A hook only replaces the import it found, so a missing one is never called. */
    }
    if (g_trace || g_watchdog || g_fallback) {
        /* All of these must be found together: the watchdog relies on each. */
        void *o  = patch_import("WINMM.dll", "waveOutOpen", hook_waveOutOpen);
        void *wr = patch_import("WINMM.dll", "waveOutWrite", hook_waveOutWrite);
        void *rs = patch_import("WINMM.dll", "waveOutReset", hook_waveOutReset);
        void *cl = patch_import("WINMM.dll", "waveOutClose", hook_waveOutClose);
        void *up = patch_import("WINMM.dll", "waveOutUnprepareHeader", hook_waveOutUnprepareHeader);
        real_waveOutOpen = o; real_waveOutWrite = wr; real_waveOutReset = rs;
        real_waveOutClose = cl; real_waveOutUnprepareHeader = up;
        real_waveOutPause = patch_import("WINMM.dll", "waveOutPause", hook_waveOutPause);
        real_waveOutRestart = patch_import("WINMM.dll", "waveOutRestart", hook_waveOutRestart);
        real_waveOutPrepareHeader = patch_import("WINMM.dll", "waveOutPrepareHeader", hook_waveOutPrepareHeader);
        real_waveOutGetVolume = patch_import("WINMM.dll", "waveOutGetVolume", hook_waveOutGetVolume);
        real_waveOutSetVolume = patch_import("WINMM.dll", "waveOutSetVolume", hook_waveOutSetVolume);
        if (!(o && wr && rs && cl && up && real_waveOutPause && real_waveOutRestart &&
              real_waveOutPrepareHeader && real_waveOutGetVolume && real_waveOutSetVolume)) {
            g_watchdog = 0;
            g_fallback = 0;
            tlog("sound watchdog and fallback disabled: some sound functions were not found");
        }
        tlog("sound fallback %s%s", g_fallback ? "on" : "off", g_fallback_test ? " (FallbackTest mode)" : "");
    }
}

static LONG g_hooks_done;
static void install_hooks(void)
{
    if (InterlockedExchange(&g_hooks_done, 1)) return;
    real_GetDC = patch_import("USER32.dll", "GetDC", hook_GetDC);
    real_ReleaseDC = patch_import("USER32.dll", "ReleaseDC", hook_ReleaseDC);
    real_CreateDCA = patch_import("GDI32.dll", "CreateDCA", hook_CreateDCA);
    real_DeleteDC = patch_import("GDI32.dll", "DeleteDC", hook_DeleteDC);
    real_BitBlt = patch_import("GDI32.dll", "BitBlt", hook_BitBlt);
    real_StretchDIBits = patch_import("GDI32.dll", "StretchDIBits", hook_StretchDIBits);
    real_SetDIBitsToDevice = patch_import("GDI32.dll", "SetDIBitsToDevice", hook_SetDIBitsToDevice);
    /* BeginPaint/EndPaint are always watched: the transition fix needs to
       know when the game is inside its own repaint. */
    real_BeginPaint = patch_import("USER32.dll", "BeginPaint", hook_BeginPaint);
    real_EndPaint = patch_import("USER32.dll", "EndPaint", hook_EndPaint);
    if (!real_BeginPaint) real_BeginPaint = BeginPaint;
    if (!real_EndPaint) real_EndPaint = EndPaint;
    if (g_log) {
        real_InvalidateRect = patch_import("USER32.dll", "InvalidateRect", hook_InvalidateRect);
        real_ValidateRect = patch_import("USER32.dll", "ValidateRect", hook_ValidateRect);
        real_ScrollDC = patch_import("USER32.dll", "ScrollDC", hook_ScrollDC);
        real_UpdateWindow = patch_import("USER32.dll", "UpdateWindow", hook_UpdateWindow);
        if (!real_InvalidateRect) real_InvalidateRect = InvalidateRect;
        if (!real_ValidateRect) real_ValidateRect = ValidateRect;
        if (!real_ScrollDC) real_ScrollDC = ScrollDC;
        if (!real_UpdateWindow) real_UpdateWindow = UpdateWindow;
    }
    /* If a function wasn't found, fall back to calling Windows directly. */
    if (!real_GetDC) real_GetDC = GetDC;
    if (!real_ReleaseDC) real_ReleaseDC = ReleaseDC;
    if (!real_CreateDCA) real_CreateDCA = CreateDCA;
    if (!real_DeleteDC) real_DeleteDC = DeleteDC;
    if (!real_BitBlt) real_BitBlt = BitBlt;
    if (!real_StretchDIBits) real_StretchDIBits = StretchDIBits;
    if (!real_SetDIBitsToDevice) real_SetDIBitsToDevice = SetDIBitsToDevice;
    if (g_log) wlog("hooks installed");
}

/* ---- settings and logging ---------------------------------------------- */
static void path_next_to_dll(char *out, const char *name)
{
    char *slash;
    GetModuleFileNameA(g_inst, out, MAX_PATH);
    slash = strrchr(out, '\\');
    strcpy(slash ? slash + 1 : out, name);
}

static void load_settings(void)
{
    char ini[MAX_PATH];
    path_next_to_dll(ini, "dkhelper.ini");
    g_full_redraw = GetPrivateProfileIntA("Graphics", "FullRedraw", 0, ini);
    g_fix_transitions = GetPrivateProfileIntA("Graphics", "FixTransitions", 1, ini);
    g_screen_redirect = GetPrivateProfileIntA("Graphics", "ScreenRedirect", 0, ini);
    g_log = GetPrivateProfileIntA("Graphics", "Log", 0, ini);
    g_trace = GetPrivateProfileIntA("Debug", "Trace", 0, ini);
    g_watchdog = GetPrivateProfileIntA("Sound", "Watchdog", 0, ini);
    g_sim_stall = g_watchdog && GetPrivateProfileIntA("Sound", "SimulateStall", 0, ini);
    g_fallback = GetPrivateProfileIntA("Sound", "Fallback", 0, ini);
    g_fallback_test = g_fallback ? GetPrivateProfileIntA("Sound", "FallbackTest", 0, ini) : 0;
    g_video_redirect = GetPrivateProfileIntA("Video", "Redirect", 1, ini);
    g_fake_cd = GetPrivateProfileIntA("Disc", "FakeCD", 0, ini);
    if (g_fake_cd) {
        char folder[MAX_PATH];
        GetPrivateProfileStringA("Disc", "Folder", "", folder, sizeof(folder), ini);
        g_disc_drive = drive_of(folder[0] ? folder : NULL);
    }
}

static void wlog(const char *fmt, ...)
{
    static LONG lines;
    char path[MAX_PATH];
    FILE *f;
    va_list ap;
    if (InterlockedIncrement(&lines) > 20000) return;      /* keep the log small */
    path_next_to_dll(path, "wing32.log");
    f = fopen(path, "a");
    if (!f) return;
    fprintf(f, "%8lu ", (unsigned long)GetTickCount());
    va_start(ap, fmt); vfprintf(f, fmt, ap); va_end(ap);
    fputc('\n', f);
    fclose(f);
}

/* ---- dkhelper launch ---------------------------------------------------
 * The first time the game creates a WinG DC (right at start-up), start
 * dkhelper.exe from this DLL's folder. It adds controller support and exits
 * by itself when the game closes.                                          */
static LONG g_helper_started;

static void start_helper(void)
{
    char path[MAX_PATH], cmd[MAX_PATH + 32];
    STARTUPINFOA si;
    PROCESS_INFORMATION pi;
    if (InterlockedExchange(&g_helper_started, 1)) return;
    path_next_to_dll(path, "dkhelper.exe");
    if (GetFileAttributesA(path) == INVALID_FILE_ATTRIBUTES) return;   /* optional */
    wsprintfA(cmd, "\"%s\" %lu", path, GetCurrentProcessId());
    ZeroMemory(&si, sizeof(si));
    si.cb = sizeof(si);
    if (CreateProcessA(path, cmd, NULL, NULL, FALSE, CREATE_NO_WINDOW, NULL, NULL, &si, &pi)) {
        CloseHandle(pi.hThread);
        CloseHandle(pi.hProcess);
    }
}

BOOL WINAPI DllMain(HINSTANCE inst, DWORD reason, LPVOID reserved)
{
    (void)reserved;
    if (reason == DLL_PROCESS_ATTACH) { g_inst = inst; load_settings(); install_disc_hooks(); }
    return TRUE;
}
