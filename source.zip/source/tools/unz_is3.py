"""Extract files from an InstallShield 3 .Z archive (e.g. DKSETUP\\SYSTEM\\WING.Z).

Usage: python unz_is3.py ARCHIVE.Z OUTPUT_DIR [--list]

Files inside are compressed with PKWARE DCL "implode"; the decoder below is a
Python port of Mark Adler's blast.c (zlib contrib).
"""
import os
import struct
import sys

# ---------------------------------------------------------------- blast ----
MAXBITS = 13


class _State:
    def __init__(self, data):
        self.data = data
        self.pos = 0
        self.bitbuf = 0
        self.bitcnt = 0
        self.out = bytearray()

    def bits(self, need):
        val = self.bitbuf
        while self.bitcnt < need:
            if self.pos >= len(self.data):
                raise ValueError('ran out of input')
            val |= self.data[self.pos] << self.bitcnt
            self.pos += 1
            self.bitcnt += 8
        self.bitbuf = val >> need
        self.bitcnt -= need
        return val & ((1 << need) - 1)


class _Huffman:
    def __init__(self, rep):
        # rep: compact run-length description, as in blast.c
        length = []
        for r in rep:
            n = (r >> 4) + 1
            length.extend([r & 15] * n)
        self.count = [0] * (MAXBITS + 1)
        for l in length:
            self.count[l] += 1
        offs = [0] * (MAXBITS + 1)
        for l in range(1, MAXBITS):
            offs[l + 1] = offs[l] + self.count[l]
        self.symbol = [0] * len(length)
        for sym, l in enumerate(length):
            if l:
                self.symbol[offs[l]] = sym
                offs[l] += 1

    def decode(self, s):
        code = first = index = 0
        for l in range(1, MAXBITS + 1):
            code |= s.bits(1) ^ 1          # codes are stored inverted
            count = self.count[l]
            if code < first + count:
                return self.symbol[index + (code - first)]
            index += count
            first += count
            first <<= 1
            code <<= 1
        raise ValueError('bad code')


_LITLEN = [11, 124, 8, 7, 28, 7, 188, 13, 76, 4, 10, 8, 12, 10, 12, 10, 8, 23,
           8, 9, 7, 6, 7, 8, 7, 6, 55, 8, 23, 24, 12, 11, 7, 9, 11, 12, 6, 7,
           22, 5, 7, 24, 6, 11, 9, 6, 7, 22, 7, 11, 38, 7, 9, 8, 25, 11, 8, 11,
           9, 12, 8, 12, 5, 38, 5, 38, 5, 11, 7, 5, 6, 21, 6, 10, 53, 8, 7, 24,
           10, 27, 44, 253, 253, 253, 252, 252, 252, 13, 12, 45, 12, 45, 12, 61,
           12, 45, 44, 173]
_LENLEN = [2, 35, 36, 53, 38, 23]
_DISTLEN = [2, 20, 53, 230, 247, 151, 248]
_BASE = [3, 2, 4, 5, 6, 7, 8, 9, 10, 12, 16, 24, 40, 72, 136, 264]
_EXTRA = [0, 0, 0, 0, 0, 0, 0, 0, 1, 2, 3, 4, 5, 6, 7, 8]

_litcode = _Huffman(_LITLEN)
_lencode = _Huffman(_LENLEN)
_distcode = _Huffman(_DISTLEN)


def blast(data):
    s = _State(data)
    lit = s.bits(8)
    if lit > 1:
        raise ValueError('bad literal flag')
    dictbits = s.bits(8)
    if dictbits < 4 or dictbits > 6:
        raise ValueError('bad dictionary size')
    out = s.out
    while True:
        if s.bits(1):
            symbol = _lencode.decode(s)
            length = _BASE[symbol] + s.bits(_EXTRA[symbol])
            if length == 519:
                break                       # end-of-stream marker
            symbol = 2 if length == 2 else dictbits
            dist = (_distcode.decode(s) << symbol) + s.bits(symbol) + 1
            if dist > len(out):
                raise ValueError('distance too far back')
            start = len(out) - dist
            for i in range(length):
                out.append(out[start + i])
        else:
            out.append(_litcode.decode(s) if lit else s.bits(8))
    return bytes(out)

# ------------------------------------------------------------ IS3 archive --


def read_archive(path):
    d = open(path, 'rb').read()
    if d[:4] != b'\x13\x5d\x65\x8c':
        raise ValueError('not an InstallShield 3 .Z archive')
    nfiles = struct.unpack_from('<H', d, 0x0C)[0]
    table = struct.unpack_from('<I', d, 0x29)[0]
    ndirs = struct.unpack_from('<H', d, 0x31)[0]
    pos = table
    for _ in range(ndirs):                  # skip directory records
        entry_len = struct.unpack_from('<H', d, pos + 2)[0]
        pos += entry_len
    files = []
    for _ in range(nfiles):
        orig, comp, off = struct.unpack_from('<III', d, pos + 3)
        entry_len = struct.unpack_from('<H', d, pos + 0x17)[0]
        name_len = d[pos + 0x1D]
        name = d[pos + 0x1E: pos + 0x1E + name_len].decode('ascii')
        files.append((name, orig, comp, off))
        pos += entry_len
    return d, files


def main():
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(1)
    d, files = read_archive(sys.argv[1])
    outdir = sys.argv[2]
    for name, orig, comp, off in files:
        print(f'{name:16} {orig:8} bytes (packed {comp})')
        if '--list' in sys.argv:
            continue
        data = blast(d[off:off + comp])
        if len(data) != orig:
            raise ValueError(f'{name}: size mismatch {len(data)} != {orig}')
        os.makedirs(outdir, exist_ok=True)
        with open(os.path.join(outdir, name), 'wb') as f:
            f.write(data)


if __name__ == '__main__':
    main()
