"""Fix the game's startup sound check for modern Windows.

At 0x4DFF53 the game builds a test MS ADPCM format (22050 Hz mono, 512-byte
blocks) with wSamplesPerBlock = 76. The correct value for that block size is
1012 (the game's own WAV files use 1012). Windows 95's codec ignored the bad
value; Windows 10/11 reject the format, so the game wrongly reports
"The sound decompression software has not been installed properly" (msg 1058).

This changes the instruction  mov word [ecx+0x12], 0x004C
                         to   mov word [ecx+0x12], 0x03F4

Usage: python patch_adpcm_check.py "Dinosaur Hunter.exe"
A backup is written next to it as "Dinosaur Hunter.exe.orig".
"""
import shutil
import sys

path = sys.argv[1]
OLD = bytes.fromhex('8b4dec 66c74112 4c00 8b55ec 66c74214 0700'.replace(' ', ''))
NEW = bytes.fromhex('8b4dec 66c74112 f403 8b55ec 66c74214 0700'.replace(' ', ''))

data = bytearray(open(path, 'rb').read())
if data.count(NEW) == 1 and data.count(OLD) == 0:
    print('already patched')
    sys.exit(0)
if data.count(OLD) != 1:
    sys.exit(f'expected exactly one match, found {data.count(OLD)}; not patching')
pos = data.find(OLD)
shutil.copyfile(path, path + '.orig')
data[pos:pos + len(OLD)] = NEW
open(path, 'wb').write(data)
print(f'patched at file offset {pos + 7:#x}: 4C 00 -> F4 03 (backup: {path}.orig)')
