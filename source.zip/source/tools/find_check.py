"""Find where the game pushes a given message ID and show nearby Windows API calls.

Usage: python find_check.py GAME.EXE MESSAGE_ID [WINDOW_BYTES]
Prints each "push MESSAGE_ID" location with the imported functions called in
the bytes before it (direct `call [IAT]` and `call thunk` patterns).
"""
import struct
import sys

exe = open(sys.argv[1], 'rb').read()
msg = int(sys.argv[2], 0)
window = int(sys.argv[3]) if len(sys.argv) > 3 else 400

pe = struct.unpack_from('<I', exe, 0x3C)[0]
nsec = struct.unpack_from('<H', exe, pe + 6)[0]
optsize = struct.unpack_from('<H', exe, pe + 20)[0]
opt = pe + 24
base = struct.unpack_from('<I', exe, opt + 28)[0]
imp_rva = struct.unpack_from('<I', exe, opt + 104)[0]
secs = []
for i in range(nsec):
    s = pe + 24 + optsize + i * 40
    name = exe[s:s + 8].rstrip(b'\0').decode()
    vsize, va, rsize, rptr = struct.unpack_from('<IIII', exe, s + 8)
    secs.append((name, va, max(vsize, rsize), rptr, rsize))


def off(rva):
    for _, va, size, raw, _ in secs:
        if va <= rva < va + size:
            return rva - va + raw
    return None


def rva_of(o):
    for _, va, size, raw, rsize in secs:
        if raw <= o < raw + rsize:
            return o - raw + va
    return None


# Map IAT slot address -> "DLL!Function"
iat = {}
p = off(imp_rva)
while True:
    oft, _, _, name_rva, ft = struct.unpack_from('<IIIII', exe, p)
    if not name_rva:
        break
    dll = exe[off(name_rva):exe.index(b'\0', off(name_rva))].decode()
    look = oft or ft
    i = 0
    while True:
        ent = struct.unpack_from('<I', exe, off(look) + 4 * i)[0]
        if not ent:
            break
        if ent & 0x80000000:
            fn = f'#{ent & 0xffff}'
        else:
            q = off(ent) + 2
            fn = exe[q:exe.index(b'\0', q)].decode()
        iat[base + ft + 4 * i] = f'{dll}!{fn}'
        i += 1
    p += 20

# Thunks: "jmp [IAT]" (FF 25 addr)
thunks = {}
for o in range(len(exe) - 6):
    if exe[o] == 0xFF and exe[o + 1] == 0x25:
        a = struct.unpack_from('<I', exe, o + 2)[0]
        if a in iat and rva_of(o) is not None:
            thunks[base + rva_of(o)] = iat[a]

pat = b'\x68' + struct.pack('<I', msg)
start = 0
while True:
    o = exe.find(pat, start)
    if o < 0:
        break
    start = o + 1
    va = base + rva_of(o)
    print(f'=== push {msg:#x} at {va:#x} (file {o:#x}) ===')
    for k in range(max(0, o - window), o + 40):
        if exe[k] == 0xFF and exe[k + 1] == 0x15:
            a = struct.unpack_from('<I', exe, k + 2)[0]
            if a in iat:
                print(f'  {base + rva_of(k):#x}: call [{iat[a]}]')
        elif exe[k] == 0xE8:
            rel = struct.unpack_from('<i', exe, k + 1)[0]
            tgt = base + rva_of(k) + 5 + rel
            if tgt in thunks:
                print(f'  {base + rva_of(k):#x}: call {thunks[tgt]}')
            elif any(va0 + base <= tgt < va0 + base + sz for _, va0, sz, _, _ in secs[:1]):
                print(f'  {base + rva_of(k):#x}: call sub_{tgt:x}')
    print('  bytes before:', exe[o - 48:o + 5].hex(' '))
