/*
 * "Play Dinosaur Hunter.exe" - launcher for the Android (Winlator / Wine)
 * package. Also works on Windows.
 *
 * Point a Winlator shortcut at this file. It:
 *   1. finds Game\DKCODE and Disc\DKDINO next to itself
 *   2. tells the game where it is installed and where its disc files are
 *   3. turns on WING32.DLL's "disc folder as CD" mode (Wine can't mount ISOs)
 *   4. under Wine, makes sure our WING32.DLL is used instead of Wine's own
 *   5. starts the game, and waits until it closes
 *
 * Build (32-bit TCC):  tcc -o "Play Dinosaur Hunter.exe" dkboot.c -luser32 -lkernel32
 */
#include <windows.h>
#include <string.h>

typedef LONG (WINAPI *RegCreateKeyExA_t)(HKEY, LPCSTR, DWORD, LPSTR, DWORD, REGSAM, void *, HKEY *, DWORD *);
typedef LONG (WINAPI *RegSetValueExA_t)(HKEY, LPCSTR, DWORD, DWORD, const BYTE *, DWORD);
typedef LONG (WINAPI *RegCloseKey_t)(HKEY);

static void fail(const char *what, const char *path)
{
    char msg[1024];
    wsprintfA(msg, "Dinosaur Hunter could not start.\n\n%s\n%s\n\n"
                   "Make sure the whole 'DK Eyewitness Dinosaur Hunter Android' folder was copied,\n"
                   "including the Game and Disc folders.", what, path ? path : "");
    MessageBoxA(NULL, msg, "Dinosaur Hunter", MB_OK | MB_ICONWARNING);
}

static int exists(const char *p) { return GetFileAttributesA(p) != INVALID_FILE_ATTRIBUTES; }

/* launcher.log in Game\DKCODE: what the launcher saw and did. */
static char g_logpath[MAX_PATH];
static void blog(const char *fmt, const char *a, const char *b)
{
    char line[1200];
    DWORD n;
    HANDLE f;
    if (!g_logpath[0]) return;
    wsprintfA(line, fmt, a ? a : "", b ? b : "");
    lstrcatA(line, "\r\n");
    f = CreateFileA(g_logpath, FILE_APPEND_DATA, FILE_SHARE_READ, NULL, OPEN_ALWAYS, 0, NULL);
    if (f == INVALID_HANDLE_VALUE) return;
    WriteFile(f, line, lstrlenA(line), &n, NULL);
    CloseHandle(f);
}

/* Under Wine: prefer our WING32.DLL over Wine's built-in one. */
static void wine_prefer_our_wing32(void)
{
    HMODULE ntdll = GetModuleHandleA("ntdll.dll");
    HMODULE adv;
    RegCreateKeyExA_t create; RegSetValueExA_t set; RegCloseKey_t close_;
    HKEY k;
    static const char value[] = "native,builtin";
    if (!ntdll || !GetProcAddress(ntdll, "wine_get_version")) return;   /* real Windows */
    adv = LoadLibraryA("advapi32.dll");
    if (!adv) return;
    create = (RegCreateKeyExA_t)GetProcAddress(adv, "RegCreateKeyExA");
    set = (RegSetValueExA_t)GetProcAddress(adv, "RegSetValueExA");
    close_ = (RegCloseKey_t)GetProcAddress(adv, "RegCloseKey");
    if (!create || !set || !close_) return;
    if (create(HKEY_CURRENT_USER, "Software\\Wine\\DllOverrides", 0, NULL, 0, KEY_SET_VALUE, NULL, &k, NULL) == 0) {
        LONG r = set(k, "wing32", 0, REG_SZ, (const BYTE *)value, sizeof(value));
        close_(k);
        blog("Wine DLL override wing32=native,builtin %s%s", r == 0 ? "set" : "FAILED", NULL);
    } else blog("Wine DLL override: could not open the registry key%s%s", NULL, NULL);
}

/* ---- game files from the user's own disc ---------------------------------
 * The release doesn't include DK's files. The disc's DKCODE folder holds the
 * game program and its companion files, so copy any that are missing into
 * Game\DKCODE (never overwriting a file that's already there, e.g. our own
 * WING32.DLL and settings), then apply the 2-byte sound-check fix.        */
static int copy_missing(const char *from, const char *to)   /* returns files copied */
{
    char pat[MAX_PATH], s[MAX_PATH], d[MAX_PATH];
    WIN32_FIND_DATAA fd;
    HANDLE h;
    int n = 0;
    CreateDirectoryA(to, NULL);
    wsprintfA(pat, "%s\\*", from);
    h = FindFirstFileA(pat, &fd);
    if (h == INVALID_HANDLE_VALUE) return 0;
    do {
        if (!strcmp(fd.cFileName, ".") || !strcmp(fd.cFileName, "..")) continue;
        wsprintfA(s, "%s\\%s", from, fd.cFileName);
        wsprintfA(d, "%s\\%s", to, fd.cFileName);
        if (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) n += copy_missing(s, d);
        else if (!exists(d) && CopyFileA(s, d, TRUE)) {
            SetFileAttributesA(d, FILE_ATTRIBUTE_NORMAL);      /* files from a disc are read-only */
            n++;
        }
    } while (FindNextFileA(h, &fd));
    FindClose(h);
    return n;
}

/* mov word [ecx+0x12], 0x004C  ->  0x03F4 (wSamplesPerBlock 76 -> 1012) */
static const BYTE PATCH_OLD[] = { 0x8B,0x4D,0xEC, 0x66,0xC7,0x41,0x12, 0x4C,0x00, 0x8B,0x55,0xEC, 0x66,0xC7,0x42,0x14, 0x07,0x00 };
static const BYTE PATCH_NEW[] = { 0x8B,0x4D,0xEC, 0x66,0xC7,0x41,0x12, 0xF4,0x03, 0x8B,0x55,0xEC, 0x66,0xC7,0x42,0x14, 0x07,0x00 };

/* 0 = patched now, 1 = already patched, -1 = couldn't (unknown version / error) */
static int patch_exe(const char *path)
{
    HANDLE f = CreateFileA(path, GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_EXISTING, 0, NULL);
    DWORD size, got, i, at = 0, olds = 0, news = 0;
    BYTE *buf;
    int r = -1;
    if (f == INVALID_HANDLE_VALUE) return -1;
    size = GetFileSize(f, NULL);
    buf = (BYTE *)HeapAlloc(GetProcessHeap(), 0, size ? size : 1);
    if (buf && ReadFile(f, buf, size, &got, NULL) && got == size) {
        for (i = 0; i + sizeof(PATCH_OLD) <= size; i++) {
            if (!memcmp(buf + i, PATCH_OLD, sizeof(PATCH_OLD))) { olds++; at = i; }
            else if (!memcmp(buf + i, PATCH_NEW, sizeof(PATCH_NEW))) news++;
        }
        if (olds == 0 && news == 1) r = 1;
        else if (olds == 1 && news == 0) {
            DWORD w;
            SetFilePointer(f, at + 7, NULL, FILE_BEGIN);
            if (WriteFile(f, PATCH_NEW + 7, 2, &w, NULL) && w == 2) r = 0;
        }
    }
    if (buf) HeapFree(GetProcessHeap(), 0, buf);
    CloseHandle(f);
    return r;
}

/* ---- video conversion ------------------------------------------------------
 * The disc's videos use Indeo, which modern Windows can't decode (sound but
 * no picture). On first start, convert them with the bundled ffmpeg
 * (Game\ffmpeg\ffmpeg.exe) to Cinepak in Game\DKCODE\VIDEOS, keeping the
 * disc's folder structure; WING32.DLL then plays those copies. The disc is
 * never changed. Skipped under Wine/Winlator (far too slow there - convert
 * on a PC first) and when ffmpeg isn't present.                            */
#define MAX_VIDEOS 64
static char g_vsrc[MAX_VIDEOS][MAX_PATH], g_vdst[MAX_VIDEOS][MAX_PATH];
static int g_nvideos;

static int is_indeo(const char *path)
{
    BYTE buf[16384];
    DWORD got = 0, i;
    HANDLE f = CreateFileA(path, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, 0, NULL);
    if (f == INVALID_HANDLE_VALUE) return 0;
    ReadFile(f, buf, sizeof(buf), &got, NULL);
    CloseHandle(f);
    for (i = 0; i + 4 <= got; i++)
        if ((buf[i] == 'I' || buf[i] == 'i') && (buf[i + 1] == 'V' || buf[i + 1] == 'v') && buf[i + 2] == '3' && buf[i + 3] == '2')
            return 1;
    return 0;
}

static void find_videos(const char *dir, const char *rel, const char *outroot)
{
    char pat[MAX_PATH], s[MAX_PATH], r[MAX_PATH];
    WIN32_FIND_DATAA fd;
    HANDLE h;
    wsprintfA(pat, "%s\\*", dir);
    h = FindFirstFileA(pat, &fd);
    if (h == INVALID_HANDLE_VALUE) return;
    do {
        size_t n = strlen(fd.cFileName);
        if (!strcmp(fd.cFileName, ".") || !strcmp(fd.cFileName, "..")) continue;
        wsprintfA(s, "%s\\%s", dir, fd.cFileName);
        if (rel[0]) wsprintfA(r, "%s\\%s", rel, fd.cFileName); else lstrcpyA(r, fd.cFileName);
        if (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) find_videos(s, r, outroot);
        else if (n > 4 && !lstrcmpiA(fd.cFileName + n - 4, ".avi") && g_nvideos < MAX_VIDEOS) {
            char d[MAX_PATH];
            wsprintfA(d, "%s\\%s", outroot, r);
            if (!exists(d) && is_indeo(s)) {
                lstrcpyA(g_vsrc[g_nvideos], s);
                lstrcpyA(g_vdst[g_nvideos], d);
                g_nvideos++;
            }
        }
    } while (FindNextFileA(h, &fd));
    FindClose(h);
}

static void make_dirs_for(const char *file)       /* create every folder above file */
{
    char p[MAX_PATH], *c;
    lstrcpyA(p, file);
    for (c = p + 3; *c; c++)
        if (*c == '\\') { *c = 0; CreateDirectoryA(p, NULL); *c = '\\'; }
}

static void pump(void)
{
    MSG m;
    while (PeekMessageA(&m, NULL, 0, 0, PM_REMOVE)) { TranslateMessage(&m); DispatchMessageA(&m); }
}

static void convert_videos(const char *base, const char *disc, const char *code)
{
    char ffmpeg[MAX_PATH], outroot[MAX_PATH], discdir[MAX_PATH], msg[300];
    HWND win = NULL;
    int ok = 0, failed = 0;
    wsprintfA(ffmpeg, "%s\\Game\\ffmpeg\\ffmpeg.exe", base);
    if (!exists(ffmpeg)) { blog("Video conversion skipped: Game\\ffmpeg\\ffmpeg.exe not found%s%s", NULL, NULL); return; }
    wsprintfA(outroot, "%s\\VIDEOS", code);
    lstrcpyA(discdir, disc);
    if (discdir[lstrlenA(discdir) - 1] == '\\') discdir[lstrlenA(discdir) - 1] = 0;
    find_videos(discdir, "", outroot);
    if (!g_nvideos) return;

    {   /* a small "please wait" window */
        int w = 460, h = 110;
        win = CreateWindowExA(WS_EX_TOPMOST | WS_EX_TOOLWINDOW, "STATIC", "", WS_POPUP | WS_BORDER | WS_VISIBLE | SS_CENTER,
                              (GetSystemMetrics(SM_CXSCREEN) - w) / 2, (GetSystemMetrics(SM_CYSCREEN) - h) / 2, w, h,
                              NULL, NULL, GetModuleHandleA(NULL), NULL);
        if (win) SendMessageA(win, WM_SETFONT, (WPARAM)GetStockObject(DEFAULT_GUI_FONT), TRUE);
    }
    {   /* several videos at once: the Cinepak encoder uses one CPU core each */
        SYSTEM_INFO sys;
        HANDLE run[8];
        int runidx[8], nrun = 0, next = 0, done = 0, jobs;
        GetSystemInfo(&sys);
        jobs = (int)sys.dwNumberOfProcessors - 1;
        if (jobs < 1) jobs = 1;
        if (jobs > 8) jobs = 8;
        while (done < g_nvideos) {
            while (nrun < jobs && next < g_nvideos) {   /* start more */
                char cmdline[3 * MAX_PATH + 260], tmp[MAX_PATH + 8];
                STARTUPINFOA si;
                PROCESS_INFORMATION pi;
                make_dirs_for(g_vdst[next]);
                wsprintfA(tmp, "%s.tmp", g_vdst[next]);
                /* fast Cinepak settings: ~3x quicker, practically the same picture */
                wsprintfA(cmdline, "\"%s\" -hide_banner -loglevel error -y -i \"%s\" -map 0 -c:v cinepak "
                                   "-max_extra_cb_iterations 0 -max_strips 1 -c:a copy -fps_mode passthrough -f avi \"%s\"",
                          ffmpeg, g_vsrc[next], tmp);
                ZeroMemory(&si, sizeof(si));
                si.cb = sizeof(si);
                if (CreateProcessA(ffmpeg, cmdline, NULL, NULL, FALSE, CREATE_NO_WINDOW | BELOW_NORMAL_PRIORITY_CLASS,
                                   NULL, NULL, &si, &pi)) {
                    CloseHandle(pi.hThread);
                    run[nrun] = pi.hProcess;
                    runidx[nrun] = next;
                    nrun++;
                } else {
                    failed++; done++;
                    blog("Video conversion could not start ffmpeg for %s%s", g_vsrc[next], NULL);
                }
                next++;
            }
            wsprintfA(msg, "\nDinosaur Hunter - first start\n\nPreparing the videos so they play on this PC: %d of %d done\n(this only happens once)",
                      done, g_nvideos);
            if (win) { SetWindowTextA(win, msg); UpdateWindow(win); }
            if (!nrun) continue;
            {
                DWORD w = MsgWaitForMultipleObjects((DWORD)nrun, run, FALSE, INFINITE, QS_ALLINPUT);
                if (w >= WAIT_OBJECT_0 && w < WAIT_OBJECT_0 + (DWORD)nrun) {
                    int k = (int)(w - WAIT_OBJECT_0), v = runidx[k];
                    char tmp[MAX_PATH + 8];
                    DWORD rc = 1;
                    GetExitCodeProcess(run[k], &rc);
                    CloseHandle(run[k]);
                    run[k] = run[nrun - 1]; runidx[k] = runidx[nrun - 1]; nrun--;
                    wsprintfA(tmp, "%s.tmp", g_vdst[v]);
                    if (rc == 0 && MoveFileA(tmp, g_vdst[v])) ok++;
                    else { DeleteFileA(tmp); failed++; blog("Video conversion failed: %s%s", g_vsrc[v], NULL); }
                    done++;
                } else pump();
            }
        }
    }
    if (win) DestroyWindow(win);
    wsprintfA(msg, "%d", ok);
    blog("Converted %s video(s) to Game\\DKCODE\\VIDEOS%s", msg, NULL);
    if (failed) MessageBoxA(NULL, "Some videos couldn't be converted. The game will still run, but those videos\n"
                                  "will play sound with no picture. It will try again next time you start the game.",
                            "Dinosaur Hunter", MB_OK | MB_ICONWARNING);
}

int WINAPI WinMain(HINSTANCE inst, HINSTANCE prev, LPSTR cmd, int show)
{
    char base[MAX_PATH], game[MAX_PATH], code[MAX_PATH], disc[MAX_PATH];
    char exe[MAX_PATH], ini[MAX_PATH], helper_ini[MAX_PATH], check[MAX_PATH], *slash;
    STARTUPINFOA si;
    PROCESS_INFORMATION pi;
    (void)inst; (void)prev; (void)cmd; (void)show;

    GetModuleFileNameA(NULL, base, MAX_PATH);
    slash = strrchr(base, '\\');
    if (slash) *slash = 0;

    wsprintfA(game, "%s\\Game\\", base);
    wsprintfA(code, "%s\\Game\\DKCODE", base);
    wsprintfA(disc, "%s\\Disc\\DKDINO\\", base);
    wsprintfA(exe, "%s\\Dinosaur Hunter.exe", code);
    wsprintfA(ini, "%s\\Dinosaur Hunter.ini", code);
    wsprintfA(helper_ini, "%s\\dkhelper.ini", code);
    wsprintfA(check, "%sINTRO", disc);

    /* Fresh logs for this run (only if the game folder is there and
       [Debug] Trace=1 in dkhelper.ini). */
    if (exists(code) && GetPrivateProfileIntA("Debug", "Trace", 0, helper_ini)) {
        char old[MAX_PATH];
        HMODULE ntdll = GetModuleHandleA("ntdll.dll");
        const char *(CDECL *wine_ver)(void) = ntdll ? (const char *(CDECL *)(void))GetProcAddress(ntdll, "wine_get_version") : NULL;
        wsprintfA(g_logpath, "%s\\launcher.log", code);
        DeleteFileA(g_logpath);
        wsprintfA(old, "%s\\startup.log", code);
        DeleteFileA(old);
        blog("Launcher started from %s%s", base, NULL);
        blog("Running on %s %s", wine_ver ? "Wine" : "Windows", wine_ver ? wine_ver() : "");
    }

    if (!exists(code)) { blog("Missing game folder: %s%s", code, NULL); fail("The game folder is missing:", code); return 1; }
    if (!exists(check)) { blog("Missing disc folder: %s%s", check, NULL); fail("The game disc folder is missing (copy your disc's files into it):", disc); return 1; }

    /* First start: bring in the game program and its files from the disc. */
    {
        char src[MAX_PATH], num[16];
        int n;
        wsprintfA(src, "%sDKCODE", disc);
        n = copy_missing(src, code);
        if (n) { wsprintfA(num, "%d", n); blog("Copied %s game file(s) from the disc's DKCODE folder%s", num, NULL); }
    }
    if (!exists(exe)) {
        blog("Missing game program: %s%s", exe, NULL);
        fail("The game program wasn't found on your disc. Expected:", "Disc\\DKDINO\\DKCODE\\Dinosaur Hunter.exe");
        return 1;
    }
    switch (patch_exe(exe)) {
    case 0: blog("Applied the sound-check fix to the game program%s%s", NULL, NULL); break;
    case 1: break;
    default:
        blog("Could not apply the sound-check fix (unknown game version)%s%s", NULL, NULL);
        MessageBoxA(NULL, "Dinosaur Hunter: the sound-check fix couldn't be applied to your copy of the game\n"
                          "(it may be a different edition of the disc). The game will try to start anyway.",
                    "Dinosaur Hunter", MB_OK | MB_ICONWARNING);
    }
    blog("Game: %s%s", exe, NULL);
    blog("Disc folder: %s%s", disc, NULL);

    {   /* first start on a PC: convert the Indeo videos (not under Wine) */
        HMODULE ntdll = GetModuleHandleA("ntdll.dll");
        if (ntdll && GetProcAddress(ntdll, "wine_get_version")) blog("Under Wine: video conversion not attempted%s%s", NULL, NULL);
        else convert_videos(base, disc, code);
    }

    /* Where the game is installed, and where its disc is. */
    WritePrivateProfileStringA("Directory", "Path", game, ini);
    WritePrivateProfileStringA("Directory", "Data", disc, ini);
    /* Disc-folder-as-CD mode in WING32.DLL. */
    WritePrivateProfileStringA("Disc", "FakeCD", "1", helper_ini);
    WritePrivateProfileStringA("Disc", "Folder", disc, helper_ini);

    wine_prefer_our_wing32();

    ZeroMemory(&si, sizeof(si));
    si.cb = sizeof(si);
    if (!CreateProcessA(exe, NULL, NULL, NULL, FALSE, 0, NULL, code, &si, &pi)) {
        char err[32];
        wsprintfA(err, "%lu", GetLastError());
        blog("Could not start the game, error %s%s", err, NULL);
        fail("Windows could not start the game program:", exe);
        return 1;
    }
    blog("Game started%s%s", NULL, NULL);
    CloseHandle(pi.hThread);
    /* Stay running until the game closes: Winlator ends a shortcut's session
       when the program it started exits. */
    WaitForSingleObject(pi.hProcess, INFINITE);
    {
        DWORD code_ = 0;
        char c[32];
        GetExitCodeProcess(pi.hProcess, &code_);
        wsprintfA(c, "0x%lX", code_);
        blog("Game closed, exit code %s%s", c, NULL);
    }
    CloseHandle(pi.hProcess);
    return 0;
}
