# Builds an ISO image from a folder using Windows' built-in IMAPI2 (no extra software).
# Usage: make_iso.ps1 -Source FOLDER -Output FILE.iso -Label DKDINO
param(
    [Parameter(Mandatory)] [string]$Source,
    [Parameter(Mandatory)] [string]$Output,
    [string]$Label = 'DKDINO'
)
$ErrorActionPreference = 'Stop'

# IStream -> file writer (IMAPI2 hands back a COM stream)
if (-not ('IsoWriter' -as [type])) {
    Add-Type -TypeDefinition @'
using System; using System.IO; using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;
public static class IsoWriter {
    public static void Save(object comStream, string path) {
        IStream s = (IStream)comStream;
        System.Runtime.InteropServices.ComTypes.STATSTG st;
        s.Stat(out st, 1);
        byte[] buf = new byte[2048 * 512];
        IntPtr readPtr = Marshal.AllocHGlobal(4);
        try {
            using (FileStream fs = File.Create(path)) {
                long left = st.cbSize;
                while (left > 0) {
                    int want = (int)Math.Min(buf.Length, left);
                    s.Read(buf, want, readPtr);
                    int got = Marshal.ReadInt32(readPtr);
                    if (got <= 0) break;
                    fs.Write(buf, 0, got);
                    left -= got;
                }
            }
        } finally { Marshal.FreeHGlobal(readPtr); }
    }
}
'@
}

$fsi = New-Object -ComObject IMAPI2FS.MsftFileSystemImage
$fsi.FileSystemsToCreate = 3          # ISO 9660 + Joliet (keeps long names like "Dinosaur Hunter.exe")
$fsi.VolumeName = $Label
$fsi.FreeMediaBlocks = 0              # no size limit (not burning to a real disc)
$fsi.Root.AddTree($Source, $false)    # add folder contents at the image root
$result = $fsi.CreateResultImage()
[IsoWriter]::Save($result.ImageStream, $Output)
"Wrote $Output ({0:N1} MB), label $Label" -f ((Get-Item $Output).Length / 1MB)
