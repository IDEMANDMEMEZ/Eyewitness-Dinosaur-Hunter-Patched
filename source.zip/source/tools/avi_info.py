"""Print the video/audio format of AVI files (codec FourCC, size, frames, audio).
Usage: python avi_info.py FILE_OR_FOLDER ..."""
import os
import struct
import sys


def info(path):
    d = open(path, 'rb').read(64 * 1024)
    out = {}
    pos = d.find(b'avih')
    if pos >= 0:
        usec, _, _, _, frames, _, streams, _, w, h = struct.unpack_from('<10I', d, pos + 8)
        out.update(fps=round(1e6 / usec, 2) if usec else 0, frames=frames, streams=streams, size=f'{w}x{h}')
    p = 0
    while True:
        p = d.find(b'strh', p)
        if p < 0:
            break
        kind = d[p + 8:p + 12].decode('latin1')
        handler = d[p + 12:p + 16].decode('latin1')
        f = d.find(b'strf', p)
        if kind == 'vids' and f >= 0:
            bits = struct.unpack_from('<H', d, f + 8 + 14)[0]
            comp = d[f + 8 + 16:f + 8 + 20].decode('latin1')
            out['video'] = f'{handler}/{comp} {bits}bpp'
        elif kind == 'auds' and f >= 0:
            tag, ch, rate = struct.unpack_from('<HHI', d, f + 8)
            bits = struct.unpack_from('<H', d, f + 8 + 14)[0]
            out['audio'] = f'tag={tag:#06x} {ch}ch {rate}Hz {bits}bit'
        p += 4
    return out


files = []
for a in sys.argv[1:]:
    if os.path.isdir(a):
        for r, _, fs in os.walk(a):
            files += [os.path.join(r, f) for f in fs if f.lower().endswith('.avi')]
    else:
        files.append(a)
for f in sorted(files):
    print(os.path.relpath(f, sys.argv[1]) if os.path.isdir(sys.argv[1]) else f, info(f))
