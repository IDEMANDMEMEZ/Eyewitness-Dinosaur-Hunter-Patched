"""List a 32-bit PE file's imported functions, grouped by DLL.
Usage: python list_imports.py FILE.exe [filter-regex]"""
import re
import struct
import sys

exe = open(sys.argv[1], 'rb').read()
flt = re.compile(sys.argv[2], re.I) if len(sys.argv) > 2 else None
pe = struct.unpack_from('<I', exe, 0x3C)[0]
nsec = struct.unpack_from('<H', exe, pe + 6)[0]
optsize = struct.unpack_from('<H', exe, pe + 20)[0]
opt = pe + 24
imp_rva = struct.unpack_from('<I', exe, opt + 104)[0]
secs = []
for i in range(nsec):
    s = pe + 24 + optsize + i * 40
    vsize, va, rsize, rptr = struct.unpack_from('<IIII', exe, s + 8)
    secs.append((va, max(vsize, rsize), rptr))


def off(rva):
    for va, size, raw in secs:
        if va <= rva < va + size:
            return rva - va + raw


p = off(imp_rva)
while True:
    oft, _, _, name_rva, ft = struct.unpack_from('<IIIII', exe, p)
    if not name_rva:
        break
    dll = exe[off(name_rva):exe.index(b'\0', off(name_rva))].decode()
    names = []
    i = 0
    look = oft or ft
    while True:
        ent = struct.unpack_from('<I', exe, off(look) + 4 * i)[0]
        if not ent:
            break
        if ent & 0x80000000:
            names.append(f'#{ent & 0xffff}')
        else:
            q = off(ent) + 2
            names.append(exe[q:exe.index(b'\0', q)].decode())
        i += 1
    if flt:
        names = [n for n in names if flt.search(n)]
    if names:
        print(f'{dll} ({len(names)}): ' + ', '.join(sorted(names)))
    p += 20
