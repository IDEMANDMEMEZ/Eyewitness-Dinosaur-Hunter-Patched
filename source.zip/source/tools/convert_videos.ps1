# Converts every Indeo (IV32) AVI in an unpacked Dinosaur Hunter disc to Cinepak, in place,
# so the videos show a picture on modern Windows (which no longer has the Indeo codec).
# - Video: Indeo 3.2 -> Cinepak, same size (320x240), same frame rate, same frame count
# - Audio: copied unchanged
# - Originals are moved to -Backup with the same folder structure
#
# Needs ffmpeg + ffprobe (e.g. the "essentials" build from https://www.gyan.dev/ffmpeg/builds/).
# Usage:
#   powershell -ExecutionPolicy Bypass -File convert_videos.ps1 -Root "C:\path\to\Disc\DKDINO"
#   (add -FFmpeg "C:\ffmpeg\bin\ffmpeg.exe" if ffmpeg isn't on your PATH)
param(
    [Parameter(Mandatory)] [string]$Root,          # the unpacked disc folder (contains INTRO, DKCODE, ...)
    [string]$Backup = '',                          # default: "<Root> original videos" next to it
    [string]$FFmpeg = 'ffmpeg'                     # path to ffmpeg.exe, or 'ffmpeg' if on PATH
)
$ErrorActionPreference = 'Stop'
$Root = (Resolve-Path $Root).Path.TrimEnd('\')
if (-not $Backup) { $Backup = "$Root original videos" }
$ffmpegExe = (Get-Command $FFmpeg).Source
$ffprobe = Join-Path (Split-Path $ffmpegExe) 'ffprobe.exe'
if (-not (Test-Path $ffprobe)) { throw "ffprobe.exe not found next to $ffmpegExe" }

function Frames($f) { [int](& $ffprobe -v error -count_packets -select_streams v:0 -show_entries stream=nb_read_packets -of csv=p=0 $f) }
function Codec($f)  { (& $ffprobe -v error -select_streams v:0 -show_entries stream=codec_name -of csv=p=0 $f).Trim() }

$avis = Get-ChildItem $Root -Recurse -File | Where-Object { $_.Extension -ieq '.avi' }
foreach ($a in $avis) {
    $rel = $a.FullName.Substring($Root.Length + 1)
    $codec = Codec $a.FullName
    if ($codec -ne 'indeo3') { "skip   $rel ($codec)"; continue }

    $tmp = "$($a.FullName).cinepak.avi"
    & $ffmpegExe -hide_banner -loglevel error -y -i $a.FullName -map 0 -c:v cinepak -c:a copy -fps_mode passthrough $tmp
    if ($LASTEXITCODE -ne 0) { throw "ffmpeg failed on $rel" }

    $fIn = Frames $a.FullName; $fOut = Frames $tmp
    if ($fIn -ne $fOut) { Remove-Item $tmp; throw "$rel frame count changed: $fIn -> $fOut" }

    $bak = Join-Path $Backup $rel
    New-Item -ItemType Directory -Force (Split-Path $bak) | Out-Null
    Move-Item -LiteralPath $a.FullName -Destination $bak
    Move-Item -LiteralPath $tmp -Destination $a.FullName
    "done   $rel  frames=$fOut  {0:N1} MB -> {1:N1} MB" -f ((Get-Item $bak).Length / 1MB), ((Get-Item $a.FullName).Length / 1MB)
}
