/*
 * dkhelper.exe - controller support for Dinosaur Hunter 2.0
 *
 * Started automatically by our stand-in WING32.DLL when the game starts, and
 * exits when the game exits. It only acts while the game is the active
 * window. The game itself runs in its normal window, unchanged.
 *
 * Controller (XInput: Xbox and compatible pads):
 *   Left stick  - move pointer; speed ramps up the longer it's held
 *   A           - left click (hold to drag)
 *   B           - right click (or Backspace, see dkhelper.ini)
 *   Start       - Escape key
 *
 * Settings: dkhelper.ini next to this exe (all optional):
 *   [Controller] Enabled=1  B=rightclick | backspace
 *
 * Build (64-bit TCC):
 *   x86_64-win32-tcc -o dkhelper.exe dkhelper.c -luser32
 */
#include <windows.h>
#include <math.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>

#define GAME_W 640       /* the game's design width, used for pointer speed */

typedef BOOL (WINAPI *SetDpiCtx_t)(HANDLE);

typedef struct { WORD buttons; BYTE lt, rt; SHORT lx, ly, rx, ry; } XGAMEPAD;
typedef struct { DWORD packet; XGAMEPAD pad; } XSTATE;
typedef DWORD (WINAPI *XGetState_t)(DWORD, XSTATE *);
#define XB_START 0x0010
#define XB_A     0x1000
#define XB_B     0x2000
static XGetState_t pXInputGetState;

static int g_controller = 1;
static int g_b_backspace = 0;
static DWORD g_pid;
static HWND g_game;

static void log_line(const char *fmt, ...)
{
    char path[MAX_PATH], *slash;
    FILE *f;
    va_list ap;
    GetModuleFileNameA(NULL, path, MAX_PATH);
    slash = strrchr(path, '\\');
    strcpy(slash ? slash + 1 : path, "dkhelper.log");
    f = fopen(path, "a");
    if (!f) return;
    va_start(ap, fmt); vfprintf(f, fmt, ap); va_end(ap);
    fputc('\n', f);
    fclose(f);
}

static void load_settings(void)
{
    char ini[MAX_PATH], *slash, b[32];
    GetModuleFileNameA(NULL, ini, MAX_PATH);
    slash = strrchr(ini, '\\');
    strcpy(slash ? slash + 1 : ini, "dkhelper.ini");
    g_controller = GetPrivateProfileIntA("Controller", "Enabled", 1, ini);
    GetPrivateProfileStringA("Controller", "B", "rightclick", b, sizeof(b), ini);
    g_b_backspace = (_stricmp(b, "backspace") == 0);
}

static BOOL CALLBACK find_game(HWND h, LPARAM lp)
{
    DWORD pid;
    char cls[32];
    GetWindowThreadProcessId(h, &pid);
    if (pid != g_pid || !IsWindowVisible(h)) return TRUE;
    GetClassNameA(h, cls, sizeof(cls));
    if (strcmp(cls, "DKPenge") == 0) { *(HWND *)lp = h; return FALSE; }
    return TRUE;
}

static int game_is_active(void)
{
    HWND fg = GetForegroundWindow();
    DWORD pid = 0;
    if (!fg) return 0;
    GetWindowThreadProcessId(fg, &pid);
    return pid == g_pid;              /* game window or one of its dialogs */
}

static void send_mouse(DWORD flags)
{
    INPUT in;
    ZeroMemory(&in, sizeof(in));
    in.type = INPUT_MOUSE;
    in.mi.dwFlags = flags;
    SendInput(1, &in, sizeof(in));
}

static void send_key(WORD vk, int up)
{
    INPUT in;
    ZeroMemory(&in, sizeof(in));
    in.type = INPUT_KEYBOARD;
    in.ki.wVk = vk;
    in.ki.dwFlags = up ? KEYEVENTF_KEYUP : 0;
    SendInput(1, &in, sizeof(in));
}

static void controller_tick(double dt, int active)
{
    static WORD prev;
    static double held, accx, accy;
    XSTATE st;
    WORD now, pressed, released;
    double lx, ly, mag, dz = 7849.0;     /* XInput's recommended left-stick deadzone */

    if (!pXInputGetState || !g_controller) return;
    if (pXInputGetState(0, &st) != 0) { prev = 0; held = 0; return; }
    now = st.pad.buttons;
    if (!active) {                       /* release anything held if focus is lost */
        if (prev & XB_A) send_mouse(MOUSEEVENTF_LEFTUP);
        if ((prev & XB_B) && !g_b_backspace) send_mouse(MOUSEEVENTF_RIGHTUP);
        prev = 0; held = 0; return;
    }
    pressed = now & ~prev;
    released = prev & ~now;

    /* Left stick -> pointer, in game pixels per second. Light push = slow and
       precise; holding the stick ramps up to full speed over about a second.
       The window may be enlarged by Windows' display scaling, so the speed is
       scaled to the window's real size. */
    lx = st.pad.lx; ly = -(double)st.pad.ly;
    mag = sqrt(lx * lx + ly * ly);
    if (mag > dz) {
        double n = (mag - dz) / (32767.0 - dz), speed, ramp, k = 1.0;
        POINT p;
        RECT cr;
        if (n > 1) n = 1;
        held += dt;
        ramp = held / 1.0; if (ramp > 1) ramp = 1;
        speed = n * n * (90.0 + 610.0 * ramp);           /* 90 -> 700 game px/s */
        if (g_game && GetClientRect(g_game, &cr) && cr.right > 0) k = cr.right / (double)GAME_W;
        accx += lx / mag * speed * k * dt;
        accy += ly / mag * speed * k * dt;
        GetCursorPos(&p);
        if (fabs(accx) >= 1 || fabs(accy) >= 1) {
            int mx = (int)accx, my = (int)accy;
            accx -= mx; accy -= my;
            SetCursorPos(p.x + mx, p.y + my);
        }
    } else {
        held = 0; accx = accy = 0;
    }

    if (pressed & XB_A) send_mouse(MOUSEEVENTF_LEFTDOWN);
    if (released & XB_A) send_mouse(MOUSEEVENTF_LEFTUP);
    if (g_b_backspace) {
        if (pressed & XB_B) send_key(VK_BACK, 0);
        if (released & XB_B) send_key(VK_BACK, 1);
    } else {
        if (pressed & XB_B) send_mouse(MOUSEEVENTF_RIGHTDOWN);
        if (released & XB_B) send_mouse(MOUSEEVENTF_RIGHTUP);
    }
    if (pressed & XB_START) send_key(VK_ESCAPE, 0);
    if (released & XB_START) send_key(VK_ESCAPE, 1);
    prev = now;
}

int main(int argc, char **argv)
{
    HANDLE proc;
    HMODULE xi;
    LARGE_INTEGER freq, t0, t1;

    load_settings();
    if (argc < 2) { log_line("usage: dkhelper <game process id>"); return 2; }
    g_pid = (DWORD)strtoul(argv[1], NULL, 10);
    proc = OpenProcess(SYNCHRONIZE, FALSE, g_pid);
    if (!proc) { log_line("cannot open game process %lu", g_pid); return 1; }

    {   /* work in real screen pixels, even with Windows display scaling */
        SetDpiCtx_t setctx = (SetDpiCtx_t)GetProcAddress(GetModuleHandleA("user32.dll"),
                                                         "SetProcessDpiAwarenessContext");
        if (setctx) setctx((HANDLE)-4);
    }
    xi = LoadLibraryA("xinput1_4.dll");
    if (!xi) xi = LoadLibraryA("xinput9_1_0.dll");
    if (xi) pXInputGetState = (XGetState_t)GetProcAddress(xi, "XInputGetState");
    if (!pXInputGetState) { log_line("XInput unavailable - controller disabled"); return 0; }
    if (!g_controller) { log_line("controller disabled in dkhelper.ini"); return 0; }

    log_line("started for pid %lu (controller, B=%s)", g_pid, g_b_backspace ? "backspace" : "rightclick");

    QueryPerformanceFrequency(&freq);
    QueryPerformanceCounter(&t0);
    while (WaitForSingleObject(proc, 8) == WAIT_TIMEOUT) {
        double dt;
        int active;
        QueryPerformanceCounter(&t1);
        dt = (double)(t1.QuadPart - t0.QuadPart) / freq.QuadPart;
        t0 = t1;
        if (dt > 0.1) dt = 0.1;

        if (!g_game || !IsWindow(g_game)) { g_game = NULL; EnumWindows(find_game, (LPARAM)&g_game); }
        active = g_game && game_is_active() && !IsIconic(g_game);
        controller_tick(dt, active);
    }

    log_line("game exited, helper stopping");
    return 0;
}
