@echo off
rem Double-click this to play. It runs the PowerShell launcher next to it.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Play Dinosaur Hunter.ps1"
