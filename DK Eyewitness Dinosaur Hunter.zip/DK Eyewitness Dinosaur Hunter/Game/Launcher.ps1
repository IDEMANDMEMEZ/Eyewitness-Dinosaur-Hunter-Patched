# Launcher for DK Eyewitness Virtual Reality: Dinosaur Hunter (Windows 10/11 edition).
# Run it through "Play Dinosaur Hunter.bat" in the folder above.
#
# 1. Removes the "downloaded from the internet" block from the game's files
# 2. Mounts Disc\Dinosaur Hunter.iso as a virtual CD drive (built into Windows)
# 3. First start: copies the game program and its files from the disc's DKCODE
#    folder (they aren't included in the release) and applies the 2-byte
#    sound-check fix. Files already in Game\DKCODE are never overwritten.
#    It also converts the disc's old Indeo videos with the bundled ffmpeg
#    (Game\ffmpeg) into Game\DKCODE\VIDEOS, so they show a picture.
# 4. Tells the game where it is installed and which drive the disc is in
# 5. Starts the game
# Works from any folder or drive - nothing is installed.
$ErrorActionPreference = 'Stop'

$gameRoot = $PSScriptRoot                                   # ...\Game
$pkgRoot  = Split-Path $gameRoot -Parent                    # the package folder
$iso      = Join-Path $pkgRoot 'Disc\Dinosaur Hunter.iso'
$code     = Join-Path $gameRoot 'DKCODE'
$exe      = Join-Path $code 'Dinosaur Hunter.exe'
$ini      = Join-Path $code 'Dinosaur Hunter.ini'

function Show-Problem([string]$text) {
    Add-Type -AssemblyName System.Windows.Forms
    [void][System.Windows.Forms.MessageBox]::Show($text, 'Dinosaur Hunter',
        [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Warning)
}

try {
    if (-not (Test-Path -LiteralPath $iso)) { throw "The game disc file is missing (put your disc's ISO here):`n$iso" }

    # 1. Files copied from a download or email are blocked by Windows until unblocked.
    Get-ChildItem -LiteralPath $pkgRoot -Recurse -File | Unblock-File -ErrorAction SilentlyContinue

    # 2. Only one "DKDINO" disc should be in a drive, or the game may pick the wrong one.
    $isoFull = (Resolve-Path -LiteralPath $iso).Path
    foreach ($vol in @(Get-Volume | Where-Object { $_.FileSystemLabel -eq 'DKDINO' -and $_.DriveType -eq 'CD-ROM' })) {
        try {
            $img = Get-DiskImage -Volume $vol
            if ($img -and $img.ImagePath -and $img.ImagePath -ne $isoFull) {
                Dismount-DiskImage -ImagePath $img.ImagePath | Out-Null
            }
        } catch { }   # a real CD in a real drive - leave it alone
    }

    $img = Get-DiskImage -ImagePath $isoFull
    if (-not $img.Attached) { $img = Mount-DiskImage -ImagePath $isoFull -PassThru }

    # Windows can take a moment to give the new drive a letter.
    $letter = $null
    for ($i = 0; $i -lt 20 -and -not $letter; $i++) {
        $letter = (Get-DiskImage -ImagePath $isoFull | Get-Volume).DriveLetter
        if (-not $letter) { Start-Sleep -Milliseconds 250 }
    }
    if (-not $letter) { throw 'The game disc was mounted but Windows did not give it a drive letter.' }

    # 3. Game files from the disc (first start only), then the sound-check fix.
    $discCode = "${letter}:\DKCODE"
    if (Test-Path -LiteralPath $discCode) {
        foreach ($f in Get-ChildItem -LiteralPath $discCode -Recurse -File) {
            $dest = Join-Path $code $f.FullName.Substring($discCode.Length + 1)
            if (-not (Test-Path -LiteralPath $dest)) {
                New-Item -ItemType Directory -Force -Path (Split-Path $dest) | Out-Null
                Copy-Item -LiteralPath $f.FullName -Destination $dest
                (Get-Item -LiteralPath $dest).IsReadOnly = $false     # files from a disc are read-only
                Unblock-File -LiteralPath $dest -ErrorAction SilentlyContinue   # ISO files can carry the download block
            }
        }
    }
    if (-not (Test-Path -LiteralPath $exe)) {
        throw "The game program wasn't found on your disc (expected DKCODE\Dinosaur Hunter.exe on the disc).`nIs Disc\Dinosaur Hunter.iso a Dinosaur Hunter disc?"
    }
    # mov word [ecx+0x12], 0x004C -> 0x03F4 (wSamplesPerBlock 76 -> 1012)
    $old = [byte[]](0x8B,0x4D,0xEC,0x66,0xC7,0x41,0x12,0x4C,0x00,0x8B,0x55,0xEC,0x66,0xC7,0x42,0x14,0x07,0x00)
    $new = [byte[]](0x8B,0x4D,0xEC,0x66,0xC7,0x41,0x12,0xF4,0x03,0x8B,0x55,0xEC,0x66,0xC7,0x42,0x14,0x07,0x00)
    $bytes = [System.IO.File]::ReadAllBytes($exe)
    $hex = [System.BitConverter]::ToString($bytes)
    $oldHex = [System.BitConverter]::ToString($old); $newHex = [System.BitConverter]::ToString($new)
    $oldCount = ([regex]::Matches($hex, [regex]::Escape($oldHex))).Count
    $newCount = ([regex]::Matches($hex, [regex]::Escape($newHex))).Count
    if ($oldCount -eq 1 -and $newCount -eq 0) {
        $at = $hex.IndexOf($oldHex) / 3                       # "XX-" per byte
        $bytes[$at + 7] = 0xF4; $bytes[$at + 8] = 0x03
        [System.IO.File]::WriteAllBytes($exe, $bytes)
    } elseif (-not ($oldCount -eq 0 -and $newCount -eq 1)) {
        Show-Problem "The sound-check fix couldn't be applied to your copy of the game (it may be a different edition of the disc). The game will try to start anyway."
    }

    # 3b. First start: convert the disc's Indeo videos (no picture on modern Windows)
    #     to Cinepak with the bundled ffmpeg, into Game\DKCODE\VIDEOS. WING32.DLL
    #     plays those copies. The ISO itself is never changed.
    $ffmpeg = Join-Path $gameRoot 'ffmpeg\ffmpeg.exe'
    if (Test-Path -LiteralPath $ffmpeg) {
        $discRoot = "${letter}:\"
        $outRoot = Join-Path $code 'VIDEOS'
        $todo = @()
        foreach ($v in Get-ChildItem -LiteralPath $discRoot -Recurse -File -Filter *.avi) {
            $dest = Join-Path $outRoot $v.FullName.Substring($discRoot.Length)
            if (Test-Path -LiteralPath $dest) { continue }
            $fs = [System.IO.File]::OpenRead($v.FullName)
            try { $buf = New-Object byte[] 16384; $n = $fs.Read($buf, 0, $buf.Length) } finally { $fs.Close() }
            $head = [System.Text.Encoding]::ASCII.GetString($buf, 0, $n)
            if ($head -match '(?i)iv32') { $todo += ,@($v.FullName, $dest) }
        }
        if ($todo.Count) {
            Add-Type -AssemblyName System.Windows.Forms, System.Drawing
            $form = New-Object System.Windows.Forms.Form
            $form.Text = 'Dinosaur Hunter - first start'; $form.Width = 480; $form.Height = 150
            $form.StartPosition = 'CenterScreen'; $form.FormBorderStyle = 'FixedDialog'
            $form.ControlBox = $false; $form.TopMost = $true
            $label = New-Object System.Windows.Forms.Label
            $label.SetBounds(16, 12, 440, 40)
            $bar = New-Object System.Windows.Forms.ProgressBar
            $bar.SetBounds(16, 60, 440, 22); $bar.Maximum = $todo.Count
            $form.Controls.Add($label); $form.Controls.Add($bar); $form.Show()
            # Several at once: the Cinepak encoder uses one CPU core per video.
            $jobs = [Math]::Max(1, [Math]::Min(8, [Environment]::ProcessorCount - 1))
            $failed = 0; $done = 0; $next = 0; $running = @()
            while ($done -lt $todo.Count) {
                while ($running.Count -lt $jobs -and $next -lt $todo.Count) {
                    $src, $dest = $todo[$next]
                    New-Item -ItemType Directory -Force -Path (Split-Path $dest) | Out-Null
                    $tmp = "$dest.tmp"
                    # fast Cinepak settings: ~3x quicker, practically the same picture
                    $p = Start-Process -FilePath $ffmpeg -WindowStyle Hidden -PassThru -ArgumentList @(
                        '-hide_banner', '-loglevel', 'error', '-y', '-i', "`"$src`"", '-map', '0',
                        '-c:v', 'cinepak', '-max_extra_cb_iterations', '0', '-max_strips', '1',
                        '-c:a', 'copy', '-fps_mode', 'passthrough', '-f', 'avi', "`"$tmp`"")
                    $null = $p.Handle                       # needed for ExitCode to be readable later
                    try { $p.PriorityClass = 'BelowNormal' } catch { }
                    $running += ,@($p, $tmp, $dest)
                    $next++
                }
                $label.Text = "Preparing the videos so they play on this PC: $done of $($todo.Count) done`n(this only happens once)"
                $bar.Value = $done; [System.Windows.Forms.Application]::DoEvents()
                Start-Sleep -Milliseconds 200
                $still = @()
                foreach ($job in $running) {
                    $p, $tmp, $dest = $job
                    if (-not $p.HasExited) { $still += ,$job; continue }
                    if ($p.ExitCode -eq 0 -and (Test-Path -LiteralPath $tmp)) { Move-Item -LiteralPath $tmp -Destination $dest -Force }
                    else { Remove-Item -LiteralPath $tmp -ErrorAction SilentlyContinue; $failed++ }
                    $done++
                }
                $running = $still
            }
            $form.Close()
            if ($failed) { Show-Problem "$failed video(s) couldn't be converted. The game will still run, but those videos will play sound with no picture. It will try again next time you start the game." }
        }
    }

    # 4. Point the game at its folder and the disc drive, keeping its own saved settings.
    $lines = @()
    if (Test-Path -LiteralPath $ini) { $lines = @(Get-Content -LiteralPath $ini) }
    if (-not ($lines -match '^\[Directory\]')) { $lines = @('[Directory]') + $lines }
    $lines = $lines | Where-Object { $_ -notmatch '^(Path|Data)=' }
    $out = foreach ($l in $lines) { $l; if ($l -match '^\[Directory\]') { "Path=$gameRoot\"; "Data=${letter}:\" } }
    Set-Content -LiteralPath $ini -Value $out -Encoding ASCII

    # 5. Go!
    Start-Process -FilePath $exe -WorkingDirectory $code
}
catch {
    Show-Problem ("Dinosaur Hunter could not start.`n`n" + $_.Exception.Message +
        "`n`nTips:`n- Make sure the whole 'DK Eyewitness Dinosaur Hunter' folder was copied, including the Disc folder.`n" +
        "- If the folder is on a USB stick or network drive, copy it to your PC (e.g. Documents) and try again.")
    exit 1
}
