FFMPEG (bundled for converting the game's videos)
=================================================

This folder contains FFmpeg, used once on the first start of the game to
convert the disc's old Indeo videos to Cinepak so they show a picture on
modern Windows. It is a separate program by the FFmpeg developers and is
not part of Dinosaur Hunter or of these fixes.

Version:   FFmpeg n9.0.2 (build n9.0.2-48-gd4070a14ce-20261108)
Build:     "ffmpeg-n9.0-latest-win64-lgpl-shared-9.0" from
           https://github.com/BtbN/FFmpeg-Builds (FFmpeg-Builds/FFmpeg-Builds)
Licence:   GNU Lesser General Public License version 3 (LGPL v3) -
           see LICENSE.txt in this folder.
           This is the LGPL build: it contains no GPL-only components.

Source code:
- FFmpeg source:  https://ffmpeg.org/download.html  (git tag n9.0.2, or
                  https://git.ffmpeg.org/ffmpeg.git)
- Build scripts and the exact configuration used for this build:
                  https://github.com/BtbN/FFmpeg-Builds

Only ffmpeg.exe and the libraries it needs are included (ffplay, ffprobe,
headers and documentation were left out). The files are unmodified.

Once the videos have been converted (Game\DKCODE\VIDEOS), this folder isn't
needed any more and can be deleted to save about 150 MB.
