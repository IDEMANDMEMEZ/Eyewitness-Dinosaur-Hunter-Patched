@echo off
rem Double-click this file to play Dinosaur Hunter.
rem It runs the launcher in the Game folder (mounts the game disc and starts the game).
powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0Game\Launcher.ps1"
