DK EYEWITNESS VIRTUAL REALITY: DINOSAUR HUNTER
Patched to run on Windows 10 and Windows 11
==============================================

FIRST: SUPPLY YOUR OWN GAME ISO
-------------------------------
The game files are NOT included (copyright). You must supply your own ISO
of the "Dinosaur Hunter 2.0" CD (volume label DKDINO).

1. Get your ISO: use one you already have, or make one from your CD with any
   disc-imaging program.
2. Rename it to exactly:   Dinosaur Hunter.iso
3. Place it in the Disc folder, so you have:

     DK Eyewitness Dinosaur Hunter\Disc\Dinosaur Hunter.iso

   Don't extract it - this version uses the ISO file as it is.

That's all you need to do. The first time you start the game, it:
- copies the game program from your ISO and patches it for modern Windows
- converts the disc's old videos so they show a picture on modern Windows
  (a "Preparing the videos" window shows progress - this takes
  about 3 minutes on a modern PC and only happens once)
All automatic. Your ISO itself is never changed.


HOW TO PLAY
-----------
1. Copy this whole "DK Eyewitness Dinosaur Hunter" folder to your PC
   (for example into Documents). Keep all the files and folders together.
2. Double-click "Play Dinosaur Hunter.bat".

That's it. There is nothing to install. On the first start, the game program
itself is copied from your disc into Game\DKCODE and fixed automatically.

The first time, Windows may show a blue "Windows protected your PC" box.
Click "More info", then "Run anyway". It only asks once. or might show an error box, just ignore it.


CONTROLLER
----------
An Xbox controller (or any Xbox-compatible pad) works automatically:

  Left stick  - move the pointer (it speeds up the longer you hold it)
  A           - click
  B           - right click
  Start       - Escape

You can still use the mouse and keyboard at any time.


GOOD TO KNOW
------------
- When the game starts, a "DKDINO" disc drive appears in File Explorer.
  That's the game's virtual CD. Leave it alone while you're playing.
  When you've finished, you can right-click it and choose "Eject", or just
  leave it - it disappears when you restart your PC.
- The game runs in its original 640x480 window, like it did back in the day.
- Your progress and settings are saved in the Game\DKCODE folder.


IF SOMETHING GOES WRONG
-----------------------
- "The game disc file is missing": your ISO isn't at
  Disc\Dinosaur Hunter.iso. Check the name and location (see the top of this file).
- "The game program wasn't found on your disc": the ISO isn't a Dinosaur
  Hunter disc, or isn't a complete copy (it should contain a DKCODE folder).
- "Dinosaur Hunter could not start": make sure the whole folder was copied,
  including the "Disc" folder. If it's on a USB stick or network drive,
  copy it onto your PC and try again.
- Videos play sound but no picture: the video conversion didn't finish.
  Make sure the Game\ffmpeg folder is there, then start the game again - it
  retries automatically.
- Controller does nothing: make sure the game window is the active window
  (click on it once).
- Settings for the controller and graphics fixes are in
  Game\DKCODE\dkhelper.ini (open with Notepad, or any text editor). For example, change
  B=rightclick to B=backspace to make B press Backspace instead.


WHAT'S BEEN CHANGED FROM THE ORIGINAL CD
----------------------------------------
- The game disc is yours and is used unchanged. Its 20 old "Indeo" videos
  are converted once to a format Windows still plays (Cinepak) and kept in
  Game\DKCODE\VIDEOS. WING32.DLL plays those copies instead.
- Game\ffmpeg is FFmpeg, the free tool that does the video conversion
  (LGPL licence - see the notice in that folder). Once Game\DKCODE\VIDEOS
  exists you can delete Game\ffmpeg to save about 150 MB.
- Dinosaur Hunter.exe (copied from your disc) gets one tiny fix (2 bytes),
  applied automatically, so its sound check passes on modern Windows.
- WING32.DLL is a new, modern replacement for the old WinG graphics library
  (the original only worked on Windows 95). It also fixes graphical glitches.
- dkhelper.exe adds controller support. It starts and stops with the game.
