DK EYEWITNESS VIRTUAL REALITY: DINOSAUR HUNTER - PORTABLE EDITION
Patched to run on Windows 10 and Windows 11
================================================================

FIRST: SUPPLY YOUR OWN GAME ISO AND EXTRACT IT
----------------------------------------------
The game files are NOT included (copyright). You must supply your own ISO
of the "Dinosaur Hunter 2.0" CD (volume label DKDINO) and extract its files
into this folder:

     DK Eyewitness Dinosaur Hunter Portable\Disc\DKDINO\

How to extract your ISO:
1. Windows 10/11: double-click your .iso file. It opens as a new drive.
   Select everything on that drive (Ctrl+A), copy it (Ctrl+C), open
   Disc\DKDINO in this folder and paste (Ctrl+V). Then right-click the drive
   and choose "Eject".
   Or, with 7-Zip: right-click the .iso > 7-Zip > "Extract files...", and
   extract to Disc\DKDINO.
   (Got the CD instead of an ISO? Copy everything from the CD the same way.)
2. Check the extracted folders are DIRECTLY inside DKDINO, not one level deeper:

     Disc\DKDINO\INTRO\
     Disc\DKDINO\DKCODE\
     Disc\DKDINO\DKSETUP\
     Disc\DKDINO\DCR\, DER\, DNH\ ... (the game's content folders)
     Disc\DKDINO\Autorun.exe, SETUP.EXE, ReadMe.rtf ...

That's all you need to do. The first time you start the game, it:
- copies the game program from Disc\DKDINO\DKCODE and patches it for
  modern Windows
- converts the disc's old videos so they show a picture on modern Windows
  (a "Preparing the videos" window shows progress - this takes
  about 3 minutes on a modern PC and only happens once)
All automatic. Your extracted files are never changed.


HOW TO PLAY
-----------
1. Copy this whole "DK Eyewitness Dinosaur Hunter Portable" folder wherever
   you like: Documents, another drive, a USB stick. Keep all the files and
   folders together.
2. Double-click "Play Dinosaur Hunter.exe".

That's it. There is nothing to install. The disc is a normal folder
(Disc\DKDINO), so there's no ISO to mount and no virtual drive to set up.
On the first start, the game program itself is copied from Disc\DKDINO\DKCODE
into Game\DKCODE and fixed automatically.

The first time, Windows may show a blue "Windows protected your PC" box.
Click "More info", then "Run anyway". It only asks once.


CONTROLLER
----------
An Xbox controller (or any Xbox-compatible pad) works automatically:

  Left stick  - move the pointer (it speeds up the longer you hold it)
  A           - click
  B           - right click
  Start       - Escape

You can still use the mouse and keyboard at any time.


IF SOMETHING GOES WRONG
-----------------------
- "The game disc folder is missing": Disc\DKDINO\INTRO wasn't found. Your disc
  files aren't in Disc\DKDINO, or they're one folder too deep (see above).
- "The game program wasn't found on your disc": Disc\DKDINO\DKCODE\Dinosaur
  Hunter.exe is missing. Copy your disc's files again, all of them.
- "The game folder is missing": copy the whole folder again, including Game.
- Videos play sound but no picture: the video conversion didn't finish.
  Make sure the Game\ffmpeg folder is there, then start the game again - it
  retries automatically.
- Controller does nothing: click on the game window once so it's active.
- Settings for the controller and graphics fixes are in
  Game\DKCODE\dkhelper.ini (open with Notepad). For example, change
  B=rightclick to B=backspace to make B press Backspace instead.


WHAT'S DIFFERENT FROM THE WINDOWS VERSION
-----------------------------------------
- The disc is an unpacked folder (Disc\DKDINO) instead of an ISO image.
  WING32.DLL tells the game that this folder is its CD ("DKDINO").
- "Play Dinosaur Hunter.exe" replaces the Windows .bat launcher.
- Everything else (the sound fix, video conversion, page-change fix and
  controller support) is the same as the Windows version.
- Game\ffmpeg is FFmpeg, the free tool that does the video conversion
  (LGPL licence - see the notice in that folder). Once Game\DKCODE\VIDEOS
  exists you can delete Game\ffmpeg to save about 150 MB.
