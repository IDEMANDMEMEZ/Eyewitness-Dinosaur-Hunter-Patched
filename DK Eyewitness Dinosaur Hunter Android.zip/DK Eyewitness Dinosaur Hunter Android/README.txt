DK EYEWITNESS VIRTUAL REALITY: DINOSAUR HUNTER - ANDROID EDITION
For Android handhelds using Winlator
================================================================

This folder runs the game inside Winlator, an Android app that runs Windows
programs. You set it up once (about 10 minutes); after that the game starts
from a home-screen icon like any other app.

The game disc goes in as a normal folder (Disc\DKDINO), so there's no ISO
to mount and no virtual drive to set up.


0. SUPPLY YOUR OWN GAME ISO AND EXTRACT IT (on a PC, before copying to an android device)
----------------------------------------------------------------------------------
The game files are NOT included (copyright). You must supply your own ISO
of the "Dinosaur Hunter 2.0" CD (volume label DKDINO) and extract its files
into this folder:

     DK Eyewitness Dinosaur Hunter Android\Disc\DKDINO\

How to extract your ISO (on a Windows PC):
- Windows 10/11: double-click your .iso file. It opens as a new drive.
  Select everything on that drive (Ctrl+A), copy it (Ctrl+C), open
  Disc\DKDINO in this folder and paste (Ctrl+V). Then right-click the drive
  and choose "Eject".
  Or, with 7-Zip: right-click the .iso > 7-Zip > "Extract files...", and
  extract to Disc\DKDINO.
  (Got the CD instead of an ISO? Copy everything from the CD the same way.)
- Check the extracted folders are DIRECTLY inside DKDINO, not one level deeper:

     Disc\DKDINO\INTRO\
     Disc\DKDINO\DKCODE\
     Disc\DKDINO\DKSETUP\
     Disc\DKDINO\DCR\, DER\, DNH\ ... (the game's content folders)
     Disc\DKDINO\Autorun.exe, SETUP.EXE, ReadMe.rtf ...

- Still on the PC: double-click "Play Dinosaur Hunter.exe" ONCE. This first
  start copies the game program from Disc\DKDINO\DKCODE, patches it, and
  converts the disc's old videos so they show a picture (a "Preparing the
  videos" window shows progress - this takes about 3 minutes on a modern PC and only
  happens once). When the game appears, just close it.
  Do this on the PC, not on the device: converting under Winlator would take
  far too long, so the Android launcher doesn't try.
- Optional: then delete the Game\ffmpeg folder to save about 150 MB on your
  device. It's only needed for that one-time conversion.


1. INSTALL WINLATOR
-------------------
- On the device, download the latest official Winlator APK from:
      https://github.com/brunodev85/winlator/releases
  (version 11.x at the time of writing). Avoid third-party "Winlator" sites.
- Open the APK to install it. If Android asks, allow your browser / file
  manager to "install unknown apps".
- Open Winlator once and wait while it finishes setting itself up.


2. COPY THIS FOLDER TO THE DEVICE
---------------------------------
- Copy the whole "DK Eyewitness Dinosaur Hunter Android" folder into the
  device's Download folder (USB cable, SD card or cloud - any way works).
- Keep everything together: "Play Dinosaur Hunter.exe", Game and Disc.
- Winlator shows the Download folder as drive D: inside Windows.


3. CREATE A CONTAINER (Winlator's "virtual PC")
-----------------------------------------------
- In Winlator tap "+" to add a container. Suggested settings:
    Name ............ Dinosaur Hunter
    Screen Size ..... 800x600  (the game's window is 640x480 plus a title bar;
                                Winlator scales it up to fill the screen)
    Everything else . leave on the defaults
- Save it.


4. MAKE A SHORTCUT
------------------
- Start the container (play button). A Windows-style desktop appears.
- Open "My Computer" > D: > "DK Eyewitness Dinosaur Hunter Android".
- Open the menu on "Play Dinosaur Hunter.exe"
  (touch: put the pointer on it and tap with TWO fingers;
   mouse: click it, then Ctrl + click) and choose "Create Shortcut".
- Optional: double-click "Play Dinosaur Hunter.exe" now to check the game
  starts. The first start can take a while.
- Close the container (Winlator menu > Exit).


5. PUT IT ON YOUR HOME SCREEN
-----------------------------
- In Winlator open "Shortcuts" (side menu).
- Open the menu on "Play Dinosaur Hunter" and choose "Add to Home Screen".
  Tapping that icon now starts the game directly.
- Using a frontend such as ES-DE or Daijisho instead? If your Winlator build
  has "Export for Frontend" in the same menu, use that and add the exported
  file from Download\Winlator\Frontend to your frontend's Windows system.
- In the shortcut's settings you can also set things just for this game
  (screen size, controls) without changing the container.


CONTROLS
--------
The Retroid's built-in controls act as an Xbox controller:

  Left stick  - move the pointer (speeds up the longer you hold it)
  A           - click
  B           - right click
  Start       - Escape

If the controller does nothing:
- In Winlator's container (or shortcut) settings, open the input / controller
  settings and make sure the built-in controller is assigned as Player 1.
- Or use Winlator's own "Input Controls" to map the stick to the mouse and
  A to left click. If you do that, turn the game's own controller support
  off so they don't fight: open Game\DKCODE\dkhelper.ini and set Enabled=0.


IF SOMETHING GOES WRONG
-----------------------
- "The game disc folder is missing": Disc\DKDINO\INTRO wasn't found. Your disc
  files aren't in Disc\DKDINO, or they're one folder too deep (see step 0).
- "The game program wasn't found on your disc": Disc\DKDINO\DKCODE\Dinosaur
  Hunter.exe is missing. Copy your disc's files again, all of them.
- "Dinosaur Hunter could not start": the folder wasn't copied completely.
  Copy the whole folder again, including Game and Disc.
- Videos play sound but no picture: the videos weren't converted on a PC.
  Copy the folder back to a PC (with Game\ffmpeg), double-click "Play Dinosaur
  Hunter.exe" once, then copy it to the device again (see step 0).
- Black screen or nothing happens: in the container settings try a
  different Box64 preset ("Stability") or graphics driver, then try again.
- No sound: try a different audio driver in the container settings.
- The game window is cut off: set Screen Size to 800x600 or larger.
- Stuck on the DK logo, or no sound at all: the game waits for its sound to
  finish before moving on. Winlator can refuse to open sound the way the
  game asks, so WING32.DLL opens it another way ([Sound] Fallback=1), and if
  sound stops responding the game carries on silently after about 3 seconds
  ([Sound] Watchdog=1), both in Game\DKCODE\dkhelper.ini. For sound, try the
  other Audio Driver in the container settings (ALSA / PulseAudio).

TROUBLESHOOTING LOGS
- With Trace=1 under [Debug] in dkhelper.ini (the default here), each start
  writes two small logs in Game\DKCODE:
    launcher.log  - what "Play Dinosaur Hunter.exe" found and did
    startup.log   - the game's disc check, sound, videos and any messages
  plus error.log (the game's own error messages).
- If the game still won't start, copy those files to a PC and send them over.
  If startup.log is missing, Winlator didn't use the game's own WING32.DLL.
- To stop writing the logs, set Trace=0 under [Debug] in dkhelper.ini.


WHAT'S DIFFERENT FROM THE WINDOWS VERSION
-----------------------------------------
- The disc is an unpacked folder (Disc\DKDINO) instead of an ISO image.
  WING32.DLL tells the game that this folder is its CD ("DKDINO").
- "Play Dinosaur Hunter.exe" replaces the Windows .bat launcher (Winlator
  can't run PowerShell). It points the game at its folders, makes Wine use
  our WING32.DLL, starts the game and waits until it closes.
- WING32.DLL also opens sound another way when Winlator refuses the game's
  way, and keeps the game going if sound stops responding.
- Everything else (the sound-check fix, video conversion, page-change fix and
  controller support) is the same as the Windows version.
- Game\ffmpeg is FFmpeg, the free tool that does the video conversion
  (LGPL licence - see the notice in that folder).
